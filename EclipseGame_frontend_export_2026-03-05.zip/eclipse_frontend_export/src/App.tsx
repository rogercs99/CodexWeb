import { useEffect, useMemo, useState } from "react";
import { WelcomeScreen } from "./screens/WelcomeScreen";
import { TutorialScreen } from "./screens/TutorialScreen";
import { DemoMatchScreen } from "./screens/DemoMatchScreen";
import { MainMenuScreen } from "./screens/MainMenuScreen";
import { LobbyScreen } from "./screens/LobbyScreen";
import { MatchScreen } from "./screens/MatchScreen";
import { AuthScreen } from "./screens/AuthScreen";
import { audioManager } from "./audio/audioManager";
import { emitSfx, type AudioScene, type SfxType } from "./audio/events";
import { getAuthToken, getMe, logout, reportMatchResult, setAuthToken, type AuthUser } from "./lib/api";
import { configureHaptics, triggerHaptic } from "./lib/haptics";
import { SETTINGS_STORAGE_KEY, defaultGameSettings, type GameSettings } from "./types/game";

type Screen = "welcome" | "tutorial" | "demo" | "main_menu" | "lobby" | "match";

export default function App() {
  const [booting, setBooting] = useState(true);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [currentScreen, setCurrentScreen] = useState<Screen>("welcome");
  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (!raw) {
        return defaultGameSettings;
      }
      const parsed = JSON.parse(raw) as Partial<GameSettings>;
      return {
        ...defaultGameSettings,
        ...parsed,
      };
    } catch {
      return defaultGameSettings;
    }
  });

  useEffect(() => {
    const token = getAuthToken();
    if (!token) {
      setBooting(false);
      return;
    }

    let cancelled = false;
    getMe()
      .then(({ user: me }) => {
        if (!cancelled) {
          setUser(me);
        }
      })
      .catch(() => {
        setAuthToken(null);
      })
      .finally(() => {
        if (!cancelled) {
          setBooting(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
    audioManager.setVolumes({
      master: settings.masterVolume,
      music: settings.musicVolume,
      sfx: settings.sfxVolume,
    });
    configureHaptics(settings.haptics);
  }, [settings]);

  useEffect(() => {
    const unlock = () => {
      void audioManager.unlock();
    };
    const sfxHandler = (event: Event) => {
      const custom = event as CustomEvent<{ type?: SfxType }>;
      if (!custom.detail?.type) {
        return;
      }
      audioManager.playEffect(custom.detail.type);
    };
    const sceneHandler = (event: Event) => {
      const custom = event as CustomEvent<{ scene?: AudioScene }>;
      if (!custom.detail?.scene) {
        return;
      }
      audioManager.setScene(custom.detail.scene);
    };

    window.addEventListener("pointerdown", unlock, { once: true });
    window.addEventListener("eclipse:audioUnlock", unlock as EventListener);
    window.addEventListener("eclipse:sfx", sfxHandler as EventListener);
    window.addEventListener("eclipse:scene", sceneHandler as EventListener);
    return () => {
      window.removeEventListener("eclipse:audioUnlock", unlock as EventListener);
      window.removeEventListener("eclipse:sfx", sfxHandler as EventListener);
      window.removeEventListener("eclipse:scene", sceneHandler as EventListener);
    };
  }, []);

  useEffect(() => {
    const delegatedFeedback = (event: Event) => {
      const target = event.target;
      if (!(target instanceof Element)) {
        return;
      }
      const button = target.closest("button");
      if (!(button instanceof HTMLButtonElement) || button.disabled) {
        return;
      }
      if (button.dataset.feedback === "managed" || button.dataset.feedback === "off") {
        return;
      }
      void audioManager.unlock();
      emitSfx("ui_click");
      triggerHaptic("soft");
    };

    window.addEventListener("pointerup", delegatedFeedback, true);
    return () => {
      window.removeEventListener("pointerup", delegatedFeedback, true);
    };
  }, []);

  const scene = useMemo<AudioScene>(() => {
    if (!user) {
      return "auth";
    }
    if (currentScreen === "tutorial") {
      return "tutorial";
    }
    if (currentScreen === "demo" || currentScreen === "match") {
      return "match";
    }
    return "menu";
  }, [currentScreen, user]);

  useEffect(() => {
    audioManager.setScene(scene);
  }, [scene]);

  const updateSettings = (patch: Partial<GameSettings>) => {
    setSettings((prev) => ({
      ...prev,
      ...patch,
    }));
  };

  const handleLogout = async () => {
    try {
      await logout();
    } catch {
      // Ignore network logout failures and clear local session.
    } finally {
      setAuthToken(null);
      setUser(null);
      setCurrentScreen("welcome");
    }
  };

  const handlePracticeComplete = async () => {
    if (user) {
      try {
        const updatedUser = await reportMatchResult(true);
        setUser(updatedUser);
      } catch {
        // Keep local state if progression call fails.
      }
    }
    setCurrentScreen("main_menu");
  };

  if (booting) {
    return (
      <div className="eclipse-shell flex min-h-[100dvh] items-center justify-center text-[var(--eclipse-text)]">
        <p className="eclipse-subtitle text-xs text-[var(--eclipse-accent-soft)]">Sincronizando santuario...</p>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen onAuthenticated={setUser} />;
  }

  return (
    <div className="eclipse-shell h-[100dvh] w-full overflow-hidden text-[var(--eclipse-text)] font-sans antialiased selection:bg-[rgba(212,175,55,0.25)]">
      {currentScreen === "welcome" && (
        <WelcomeScreen
          user={user}
          onStartTutorial={() => setCurrentScreen("tutorial")}
          onSkip={() => setCurrentScreen("main_menu")}
        />
      )}
      {currentScreen === "tutorial" && (
        <TutorialScreen
          settings={settings}
          onComplete={() => setCurrentScreen("demo")}
        />
      )}
      {currentScreen === "demo" && (
        <DemoMatchScreen
          settings={settings}
          onSettingsChange={updateSettings}
          onComplete={handlePracticeComplete}
        />
      )}
      {currentScreen === "main_menu" && (
        <MainMenuScreen
          user={user}
          settings={settings}
          onSettingsChange={updateSettings}
          onLogout={handleLogout}
          onNavigate={(screen) => setCurrentScreen(screen)}
          onUserUpdate={setUser}
        />
      )}
      {currentScreen === "lobby" && (
        <LobbyScreen
          hostName={user.displayName}
          settings={settings}
          onSettingsChange={updateSettings}
          onBack={() => setCurrentScreen("main_menu")}
          onStart={() => setCurrentScreen("match")}
        />
      )}
      {currentScreen === "match" && (
        <MatchScreen
          settings={settings}
          onSettingsChange={updateSettings}
          onExit={() => setCurrentScreen("main_menu")}
        />
      )}
    </div>
  );
}
