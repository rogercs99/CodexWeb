import { useEffect, useMemo, useState, type ChangeEvent } from "react";
import { motion } from "motion/react";
import { FogBackground } from "../components/FogBackground";
import { Button } from "../components/Button";
import { OverlayPanel } from "../components/OverlayPanel";
import { SettingsControls } from "../components/SettingsControls";
import type { GameSettings } from "../types/game";
import type { AuthUser, ClubStats, SocialUser } from "../lib/api";
import { addFriend, getClubStats, getLeaderboard, listFriends, searchUsers, updateProfile } from "../lib/api";
import eclipseClubLogo from "../assets/eclipse-club-logo.svg";
import inframundoMark from "../assets/inframundo-mark.svg";
import { emitSfx } from "../audio/events";
import { triggerHaptic } from "../lib/haptics";
import {
  BadgeInfo,
  BookOpen,
  Camera,
  CircleUser,
  Home,
  LogOut,
  PlusCircle,
  Save,
  Shield,
  SlidersHorizontal,
  Swords,
  UserPlus2,
} from "lucide-react";

interface Props {
  user: AuthUser;
  settings: GameSettings;
  onSettingsChange: (patch: Partial<GameSettings>) => void;
  onLogout: () => void;
  onNavigate: (screen: "lobby" | "match" | "tutorial") => void;
  onUserUpdate?: (user: AuthUser) => void;
}

type MenuTab = "home" | "grimorio" | "social" | "perfil";

const emptyClubStats: ClubStats = {
  players: 0,
  friendships: 0,
  avgLevel: 0,
};

export function MainMenuScreen({
  user,
  settings,
  onSettingsChange,
  onLogout,
  onNavigate,
  onUserUpdate,
}: Props) {
  const [tab, setTab] = useState<MenuTab>("home");
  const [showProfile, setShowProfile] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [clubStats, setClubStats] = useState<ClubStats>(emptyClubStats);
  const [leaderboard, setLeaderboard] = useState<AuthUser[]>([]);
  const [friends, setFriends] = useState<SocialUser[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<SocialUser[]>([]);
  const [socialLoading, setSocialLoading] = useState(false);
  const [socialError, setSocialError] = useState("");
  const [profileUser, setProfileUser] = useState<AuthUser>(user);
  const [draftDisplayName, setDraftDisplayName] = useState(user.displayName);
  const [draftAvatarUrl, setDraftAvatarUrl] = useState(user.avatarUrl || "");
  const [profileSaving, setProfileSaving] = useState(false);
  const [profileError, setProfileError] = useState("");

  useEffect(() => {
    setProfileUser(user);
    setDraftDisplayName(user.displayName);
    setDraftAvatarUrl(user.avatarUrl || "");
  }, [user]);

  const winRate = useMemo(() => {
    if (!profileUser.matches) {
      return 0;
    }
    return Math.round((profileUser.wins / profileUser.matches) * 100);
  }, [profileUser.matches, profileUser.wins]);

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      try {
        const [stats, board, currentFriends] = await Promise.all([getClubStats(), getLeaderboard(8), listFriends()]);
        if (cancelled) {
          return;
        }
        setClubStats(stats);
        setLeaderboard(board);
        setFriends(currentFriends);
        setSocialError("");
      } catch {
        if (!cancelled) {
          setSocialError("No se pudo sincronizar datos sociales");
        }
      }
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    const runSearch = async () => {
      if (!searchQuery.trim()) {
        setSearchResults([]);
        setSocialError("");
        return;
      }

      setSocialLoading(true);
      try {
        const found = await searchUsers(searchQuery.trim(), 18);
        if (!cancelled) {
          setSearchResults(found);
          setSocialError("");
        }
      } catch (error) {
        if (!cancelled) {
          setSocialError(error instanceof Error ? error.message : "Busqueda no disponible");
        }
      } finally {
        if (!cancelled) {
          setSocialLoading(false);
        }
      }
    };

    const timer = window.setTimeout(runSearch, 260);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [searchQuery]);

  const handleAddFriend = async (targetUserId: string) => {
    try {
      emitSfx("ui_click");
      triggerHaptic("success");
      const updatedFriends = await addFriend({ targetUserId });
      setFriends(updatedFriends);
      if (searchQuery.trim()) {
        const found = await searchUsers(searchQuery.trim(), 18);
        setSearchResults(found);
      }
      setSocialError("");
    } catch (error) {
      triggerHaptic("error");
      setSocialError(error instanceof Error ? error.message : "No se pudo agregar amigo");
    }
  };

  const handleSelectTab = (nextTab: MenuTab) => {
    emitSfx("panel_open");
    triggerHaptic("soft");
    setTab(nextTab);
  };

  const handleAvatarFile = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    if (!file) {
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setDraftAvatarUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = async () => {
    setProfileSaving(true);
    setProfileError("");
    try {
      const updated = await updateProfile({
        displayName: draftDisplayName,
        avatarUrl: draftAvatarUrl.trim() || null,
      });
      emitSfx("panel_close");
      triggerHaptic("success");
      setProfileUser(updated);
      onUserUpdate?.(updated);
      setShowProfile(false);
    } catch (error) {
      triggerHaptic("error");
      setProfileError(error instanceof Error ? error.message : "No se pudo actualizar perfil");
    } finally {
      setProfileSaving(false);
    }
  };

  const ProfileIdentity = () => (
    <motion.section
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-3xl border border-[rgba(224,231,248,0.28)] bg-[linear-gradient(160deg,rgba(20,20,28,0.97),rgba(6,6,10,0.98))] p-4"
    >
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_75%_-5%,rgba(210,181,111,0.22),transparent_45%),radial-gradient(circle_at_10%_100%,rgba(120,112,255,0.18),transparent_45%)]" />
      <div className="relative flex items-center gap-4">
        <div className="relative h-[5.5rem] w-[5.5rem] overflow-hidden rounded-[1.3rem] border border-[rgba(237,241,252,0.38)] bg-[rgba(7,7,11,0.95)] shadow-[0_16px_34px_rgba(0,0,0,0.55)]">
          {profileUser.avatarUrl ? (
            <img
              src={profileUser.avatarUrl}
              alt={profileUser.displayName}
              className="h-full w-full object-cover"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-3xl font-black text-[var(--eclipse-gold)]">
              {profileUser.displayName.slice(0, 1).toUpperCase()}
            </div>
          )}
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        </div>
        <div className="min-w-0">
          <p className="eclipse-title truncate text-sm text-[var(--eclipse-accent-soft)]">{profileUser.displayName}</p>
          <p className="mt-1 truncate text-xs eclipse-muted">@{profileUser.username}</p>
          <p className="mt-2 inline-flex rounded-full border border-[rgba(210,181,111,0.5)] bg-[rgba(33,26,13,0.65)] px-2.5 py-1 text-[10px] text-[var(--eclipse-gold)]">
            Nivel {profileUser.level} · {profileUser.xp} XP
          </p>
        </div>
      </div>
      <div className="relative mt-4 grid grid-cols-3 gap-2 text-center text-xs">
        <div className="rounded-xl border border-[rgba(230,236,252,0.2)] bg-[rgba(6,7,10,0.75)] p-2">
          <p className="text-base font-extrabold">{profileUser.matches}</p>
          <p className="eclipse-muted">Partidas</p>
        </div>
        <div className="rounded-xl border border-[rgba(230,236,252,0.2)] bg-[rgba(6,7,10,0.75)] p-2">
          <p className="text-base font-extrabold">{profileUser.wins}</p>
          <p className="eclipse-muted">Victorias</p>
        </div>
        <div className="rounded-xl border border-[rgba(230,236,252,0.2)] bg-[rgba(6,7,10,0.75)] p-2">
          <p className="text-base font-extrabold">{winRate}%</p>
          <p className="eclipse-muted">Win rate</p>
        </div>
      </div>
    </motion.section>
  );

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden text-[var(--eclipse-text)] font-sans">
      <FogBackground />

      <div className="relative z-20 flex h-[100dvh] flex-col">
        <header className="px-4 pt-4 sm:px-6 sm:pt-5">
          <div className="eclipse-panel-soft flex items-center justify-between gap-3 rounded-2xl px-3 py-2.5">
            <img src={eclipseClubLogo} alt="Eclipse Club" className="h-10 w-auto" />
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="rounded-lg"
                onClick={() => {
                  setTab("perfil");
                  setShowProfile(true);
                }}
              >
                <CircleUser className="h-4 w-4" />
              </Button>
              <Button type="button" variant="ghost" size="sm" className="rounded-lg" onClick={() => setShowSettings(true)}>
                <SlidersHorizontal className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </header>

        <main className="eclipse-scrollbar flex-1 overflow-y-auto overscroll-contain px-4 pb-[calc(7.5rem+env(safe-area-inset-bottom))] pt-4 sm:px-6">
          <section className="eclipse-panel relative overflow-hidden rounded-2xl p-4">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(233,239,255,0.14),transparent_62%)]" />
            <div className="relative">
              <img src={inframundoMark} alt="Inframundo" className="mx-auto h-28 w-auto sm:h-32" />
              <p className="eclipse-subtitle mt-2 text-center text-[10px] text-[var(--eclipse-accent-soft)]">
                Santuario activo · {clubStats.players} jugadores reales
              </p>
            </div>
          </section>

          {tab === "home" && (
            <section className="mt-4 space-y-3">
              <Button variant="primary" size="xl" onClick={() => onNavigate("match")} className="w-full justify-start rounded-2xl px-6">
                <Swords className="h-5 w-5 text-[var(--eclipse-gold)]" />
                Partida rapida
              </Button>

              <Button
                variant="secondary"
                size="xl"
                onClick={() => onNavigate("tutorial")}
                className="w-full justify-start rounded-2xl px-6"
              >
                <BookOpen className="h-5 w-5 text-[var(--eclipse-gold)]" />
                Practica guiada
              </Button>

              <div className="grid grid-cols-2 gap-3">
                <Button variant="secondary" size="lg" onClick={() => onNavigate("lobby")} className="rounded-2xl text-sm">
                  <PlusCircle className="h-4 w-4 text-[var(--eclipse-gold)]" />
                  Crear sala
                </Button>
                <Button variant="secondary" size="lg" onClick={() => onNavigate("lobby")} className="rounded-2xl text-sm">
                  <UserPlus2 className="h-4 w-4 text-[var(--eclipse-gold)]" />
                  Unirse
                </Button>
              </div>

              <div className="eclipse-panel-soft rounded-2xl p-4">
                <p className="eclipse-subtitle text-[10px] text-[var(--eclipse-accent-soft)]">Top del club</p>
                <div className="mt-2 space-y-1.5">
                  {leaderboard.slice(0, 4).map((top, index) => (
                    <div key={top.id} className="flex items-center justify-between text-sm">
                      <p className="truncate">#{index + 1} {top.displayName}</p>
                      <span className="text-xs eclipse-muted">Nivel {top.level}</span>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}

          {tab === "grimorio" && (
            <section className="eclipse-panel mt-4 space-y-3 rounded-2xl p-4">
              <h2 className="eclipse-title text-sm">Grimorio de combate</h2>
              <p className="text-sm leading-relaxed eclipse-muted">
                Juega por palo o numero. Las cartas de sombra cargan Shadow, tu recurso para rituales.
              </p>
              <div className="space-y-2 text-sm">
                <p className="rounded-xl border border-[rgba(186,193,210,0.28)] bg-[rgba(9,10,14,0.9)] px-3 py-2">
                  <strong>Espejo Negro</strong>: reaccion instantanea. Si la tiras en ventana, devuelve el castigo al atacante.
                </p>
                <p className="rounded-xl border border-[rgba(186,193,210,0.28)] bg-[rgba(9,10,14,0.9)] px-3 py-2">
                  <strong>Shadow</strong>: energia oscura (0-6). Se gana principalmente jugando cartas de Sombra.
                </p>
                <p className="rounded-xl border border-[rgba(186,193,210,0.28)] bg-[rgba(9,10,14,0.9)] px-3 py-2">
                  <strong>Ritual ShadowSteal</strong>: gasta 2 Shadow para drenar recurso del rival y cortar su ventaja.
                </p>
              </div>
              <Button variant="ritual" size="lg" className="w-full rounded-xl" onClick={() => onNavigate("tutorial")}>
                Ver tutorial completo
              </Button>
            </section>
          )}

          {tab === "social" && (
            <section className="eclipse-panel mt-4 space-y-4 rounded-2xl p-4">
              <h2 className="eclipse-title text-sm">Social</h2>
              <p className="text-sm leading-relaxed eclipse-muted">
                Busca usuarios reales del club, agrega aliados y crea salas privadas.
              </p>

              <input
                value={searchQuery}
                onChange={(event) => setSearchQuery(event.currentTarget.value)}
                placeholder="Buscar por usuario o nombre..."
                className="w-full rounded-xl border border-[rgba(202,210,229,0.34)] bg-[rgba(6,7,11,0.94)] px-3 py-2 text-sm outline-none"
              />

              {socialLoading && <p className="text-xs eclipse-muted">Buscando jugadores...</p>}
              {socialError && (
                <p className="rounded-xl border border-[rgba(175,74,98,0.62)] bg-[rgba(52,16,30,0.86)] px-3 py-2 text-xs text-rose-200">
                  {socialError}
                </p>
              )}

              {searchQuery.trim() && (
                <div className="space-y-2">
                  {searchResults.length === 0 && !socialLoading && (
                    <p className="text-xs eclipse-muted">No hay resultados para esa busqueda.</p>
                  )}
                  {searchResults.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center justify-between rounded-xl border border-[rgba(192,198,214,0.28)] bg-[rgba(9,10,15,0.9)] px-3 py-2"
                    >
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold">{item.displayName}</p>
                        <p className="truncate text-xs eclipse-muted">@{item.username} · Nivel {item.level}</p>
                      </div>
                      {item.isFriend ? (
                        <span className="text-xs text-emerald-300">Amigo</span>
                      ) : (
                        <Button variant="secondary" size="sm" className="rounded-lg" onClick={() => handleAddFriend(item.id)}>
                          + Amigo
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              )}

              <div className="rounded-xl border border-[rgba(192,198,214,0.22)] bg-[rgba(9,10,15,0.88)] p-3">
                <p className="mb-2 text-xs eclipse-subtitle text-[var(--eclipse-accent-soft)]">Mis aliados</p>
                <div className="space-y-2">
                  {friends.length === 0 && <p className="text-xs eclipse-muted">Aun no tienes amigos agregados.</p>}
                  {friends.slice(0, 6).map((ally) => (
                    <div key={ally.id} className="flex items-center justify-between text-sm">
                      <span className="truncate">{ally.displayName}</span>
                      <span className="text-xs eclipse-muted">Nivel {ally.level}</span>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          )}

          {tab === "perfil" && (
            <section className="mt-4 space-y-3">
              <ProfileIdentity />
              <div className="eclipse-panel-soft rounded-2xl p-4">
                <p className="eclipse-title text-xs text-[var(--eclipse-accent-soft)]">Rendimiento</p>
                <div className="mt-2 grid grid-cols-2 gap-3 text-sm">
                  <div className="rounded-xl border border-[rgba(201,208,226,0.24)] bg-[rgba(8,9,13,0.92)] p-3">
                    <p className="text-xl font-extrabold">{profileUser.level}</p>
                    <p className="text-xs eclipse-muted">Nivel</p>
                  </div>
                  <div className="rounded-xl border border-[rgba(201,208,226,0.24)] bg-[rgba(8,9,13,0.92)] p-3">
                    <p className="text-xl font-extrabold">{profileUser.xp}</p>
                    <p className="text-xs eclipse-muted">XP</p>
                  </div>
                  <div className="rounded-xl border border-[rgba(201,208,226,0.24)] bg-[rgba(8,9,13,0.92)] p-3">
                    <p className="text-xl font-extrabold">{profileUser.wins}</p>
                    <p className="text-xs eclipse-muted">Victorias</p>
                  </div>
                  <div className="rounded-xl border border-[rgba(201,208,226,0.24)] bg-[rgba(8,9,13,0.92)] p-3">
                    <p className="text-xl font-extrabold">{winRate}%</p>
                    <p className="text-xs eclipse-muted">Win rate</p>
                  </div>
                </div>
              </div>
              <Button variant="secondary" size="lg" className="w-full rounded-xl" onClick={() => setShowProfile(true)}>
                <BadgeInfo className="h-4 w-4 text-[var(--eclipse-gold)]" />
                Editar perfil
              </Button>
            </section>
          )}
        </main>

        <nav className="fixed inset-x-0 bottom-0 z-30">
          <div className="eclipse-bottom-nav grid grid-cols-4 px-4 pb-[calc(1.25rem+env(safe-area-inset-bottom))] pt-3">
            <button
              type="button"
              onClick={() => handleSelectTab("home")}
              className={`flex flex-col items-center gap-1 ${tab === "home" ? "text-[var(--eclipse-gold)]" : "text-[var(--eclipse-text-faint)]"}`}
            >
              <Home className="h-5 w-5" />
              <span className="eclipse-subtitle text-[9px]">Inicio</span>
            </button>
            <button
              type="button"
              onClick={() => handleSelectTab("grimorio")}
              className={`flex flex-col items-center gap-1 ${tab === "grimorio" ? "text-[var(--eclipse-gold)]" : "text-[var(--eclipse-text-faint)]"}`}
            >
              <BookOpen className="h-5 w-5" />
              <span className="eclipse-subtitle text-[9px]">Grimorio</span>
            </button>
            <button
              type="button"
              onClick={() => handleSelectTab("social")}
              className={`flex flex-col items-center gap-1 ${tab === "social" ? "text-[var(--eclipse-gold)]" : "text-[var(--eclipse-text-faint)]"}`}
            >
              <UserPlus2 className="h-5 w-5" />
              <span className="eclipse-subtitle text-[9px]">Social</span>
            </button>
            <button
              type="button"
              onClick={() => handleSelectTab("perfil")}
              className={`flex flex-col items-center gap-1 ${tab === "perfil" ? "text-[var(--eclipse-gold)]" : "text-[var(--eclipse-text-faint)]"}`}
            >
              <Shield className="h-5 w-5" />
              <span className="eclipse-subtitle text-[9px]">Perfil</span>
            </button>
          </div>
        </nav>
      </div>

      <OverlayPanel open={showSettings} title="Ajustes" onClose={() => setShowSettings(false)}>
        <SettingsControls settings={settings} onChange={onSettingsChange} />
        <div className="mt-3 space-y-2">
          <Button variant="secondary" size="md" className="w-full rounded-xl" onClick={() => setShowSettings(false)}>
            Cerrar
          </Button>
          <Button variant="danger" size="md" className="w-full rounded-xl" onClick={onLogout}>
            <LogOut className="h-4 w-4" />
            Cerrar sesion
          </Button>
        </div>
      </OverlayPanel>

      <OverlayPanel open={showProfile} title="Perfil del jugador" onClose={() => setShowProfile(false)}>
        <div className="space-y-3 text-sm">
          <div className="relative overflow-hidden rounded-2xl border border-[rgba(222,229,245,0.28)] bg-[linear-gradient(160deg,rgba(17,18,24,0.96),rgba(8,8,12,0.98))] p-3">
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_80%_0%,rgba(210,181,111,0.2),transparent_46%)]" />
            <div className="relative flex items-center gap-3">
              <div className="relative h-16 w-16 overflow-hidden rounded-xl border border-[rgba(219,225,240,0.35)] bg-[rgba(7,7,11,0.95)]">
                {draftAvatarUrl ? (
                  <img src={draftAvatarUrl} alt="Avatar" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <div className="flex h-full w-full items-center justify-center text-2xl font-black text-[var(--eclipse-gold)]">
                    {draftDisplayName.slice(0, 1).toUpperCase()}
                  </div>
                )}
              </div>
              <div className="min-w-0">
                <p className="eclipse-title truncate text-xs text-[var(--eclipse-accent-soft)]">{draftDisplayName || "Invocado"}</p>
                <p className="truncate text-xs eclipse-muted">@{profileUser.username}</p>
                <p className="mt-1 text-[11px] text-[var(--eclipse-gold)]">Carta de jugador activa</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative h-16 w-16 overflow-hidden rounded-xl border border-[rgba(219,225,240,0.35)] bg-[rgba(7,7,11,0.95)]">
              {draftAvatarUrl ? (
                <img src={draftAvatarUrl} alt="Avatar" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-2xl font-black text-[var(--eclipse-gold)]">
                  {draftDisplayName.slice(0, 1).toUpperCase()}
                </div>
              )}
            </div>
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl border border-[rgba(190,197,213,0.45)] bg-[rgba(14,15,21,0.95)] px-3 py-2 text-xs">
              <Camera className="h-4 w-4" />
              Cargar foto
              <input type="file" accept="image/*" className="hidden" onChange={handleAvatarFile} />
            </label>
          </div>

          <label className="block">
            <span className="eclipse-subtitle text-[9px] text-[var(--eclipse-accent-soft)]">Nombre visible</span>
            <input
              value={draftDisplayName}
              onChange={(event) => setDraftDisplayName(event.currentTarget.value)}
              maxLength={28}
              className="mt-1 w-full rounded-xl border border-[rgba(190,197,213,0.45)] bg-[rgba(7,8,12,0.95)] px-3 py-2 text-sm outline-none"
            />
          </label>

          <label className="block">
            <span className="eclipse-subtitle text-[9px] text-[var(--eclipse-accent-soft)]">URL de avatar (opcional)</span>
            <input
              value={draftAvatarUrl}
              onChange={(event) => setDraftAvatarUrl(event.currentTarget.value)}
              placeholder="https://..."
              className="mt-1 w-full rounded-xl border border-[rgba(190,197,213,0.45)] bg-[rgba(7,8,12,0.95)] px-3 py-2 text-sm outline-none"
            />
          </label>

          {profileError && (
            <p className="rounded-xl border border-[rgba(175,74,98,0.65)] bg-[rgba(63,18,34,0.82)] px-3 py-2 text-xs text-rose-200">
              {profileError}
            </p>
          )}

          <Button
            variant="ritual"
            size="md"
            className="w-full rounded-xl"
            onClick={handleSaveProfile}
            disabled={profileSaving}
          >
            <Save className="h-4 w-4" />
            {profileSaving ? "Guardando..." : "Guardar cambios"}
          </Button>
        </div>
      </OverlayPanel>
    </div>
  );
}
