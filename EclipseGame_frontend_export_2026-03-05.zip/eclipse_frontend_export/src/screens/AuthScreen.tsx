import { type FormEvent, useState } from "react";
import { motion } from "motion/react";
import { Lock, Sparkles, UserRound } from "lucide-react";
import { Button } from "../components/Button";
import { FogBackground } from "../components/FogBackground";
import { emitAudioUnlock, emitSfx } from "../audio/events";
import type { AuthUser } from "../lib/api";
import { login, register, setAuthToken } from "../lib/api";
import { triggerHaptic } from "../lib/haptics";

type AuthMode = "login" | "register";

interface Props {
  onAuthenticated: (user: AuthUser) => void;
}

export function AuthScreen({ onAuthenticated }: Props) {
  const [mode, setMode] = useState<AuthMode>("login");
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setLoading(true);
    setError("");
    emitAudioUnlock();
    emitSfx("ui_click");

    try {
      const payload = mode === "register" ? { username, password, displayName } : { username, password };
      const session =
        mode === "register"
          ? await register(payload as { username: string; password: string; displayName?: string })
          : await login(payload as { username: string; password: string });
      setAuthToken(session.token);
      onAuthenticated(session.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo autenticar");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative h-[100dvh] overflow-hidden">
      <FogBackground />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(130,88,219,0.35),transparent_55%)]" />

      <div className="relative z-10 mx-auto flex h-[100dvh] w-full max-w-md flex-col justify-center px-6 py-10">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="rounded-3xl border border-[rgba(114,88,184,0.6)] bg-[linear-gradient(180deg,rgba(31,22,58,0.96),rgba(10,8,20,0.98))] p-6 shadow-[0_25px_70px_rgba(2,1,7,0.75)]"
        >
          <div className="mb-5 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-[rgba(200,154,23,0.45)] bg-[rgba(200,154,23,0.12)]">
              <Sparkles className="h-5 w-5 text-[var(--eclipse-gold)]" />
            </div>
            <div>
              <p className="eclipse-title text-xl leading-none">Eclipse Club</p>
              <p className="eclipse-subtitle mt-1 text-[9px] text-[var(--eclipse-accent-soft)]">
                Acceso al santuario
              </p>
            </div>
          </div>

          <div className="mb-5 grid grid-cols-2 rounded-xl border border-[rgba(91,69,149,0.6)] bg-[rgba(13,10,24,0.92)] p-1">
            <button
              type="button"
              onClick={() => {
                triggerHaptic("soft");
                emitSfx("panel_open");
                setMode("login");
              }}
              className={`rounded-lg px-3 py-2 text-sm font-semibold ${mode === "login" ? "bg-[rgba(157,118,255,0.22)] text-[var(--eclipse-text)]" : "text-[var(--eclipse-text-faint)]"}`}
            >
              Entrar
            </button>
            <button
              type="button"
              onClick={() => {
                triggerHaptic("soft");
                emitSfx("panel_open");
                setMode("register");
              }}
              className={`rounded-lg px-3 py-2 text-sm font-semibold ${mode === "register" ? "bg-[rgba(157,118,255,0.22)] text-[var(--eclipse-text)]" : "text-[var(--eclipse-text-faint)]"}`}
            >
              Registrarme
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <label className="block">
              <span className="eclipse-subtitle text-[9px] text-[var(--eclipse-accent-soft)]">Usuario (sin espacios)</span>
              <div className="mt-1 flex items-center gap-2 rounded-xl border border-[rgba(92,70,149,0.75)] bg-[rgba(12,10,23,0.95)] px-3">
                <UserRound className="h-4 w-4 text-[var(--eclipse-text-faint)]" />
                <input
                  value={username}
                  onChange={(event) => setUsername(event.currentTarget.value)}
                  placeholder="Ejemplo: eclipseplayer"
                  className="w-full bg-transparent py-3 text-sm outline-none"
                  autoComplete="username"
                  required
                />
              </div>
            </label>

            {mode === "register" && (
              <label className="block">
                <span className="eclipse-subtitle text-[9px] text-[var(--eclipse-accent-soft)]">Nombre visible</span>
                <input
                  value={displayName}
                  onChange={(event) => setDisplayName(event.currentTarget.value)}
                  placeholder="Como te vera el club"
                  className="mt-1 w-full rounded-xl border border-[rgba(92,70,149,0.75)] bg-[rgba(12,10,23,0.95)] px-3 py-3 text-sm outline-none"
                />
              </label>
            )}

            <label className="block">
              <span className="eclipse-subtitle text-[9px] text-[var(--eclipse-accent-soft)]">Clave</span>
              <div className="mt-1 flex items-center gap-2 rounded-xl border border-[rgba(92,70,149,0.75)] bg-[rgba(12,10,23,0.95)] px-3">
                <Lock className="h-4 w-4 text-[var(--eclipse-text-faint)]" />
                <input
                  type="password"
                  value={password}
                  onChange={(event) => setPassword(event.currentTarget.value)}
                  placeholder="Minimo 6 caracteres"
                  className="w-full bg-transparent py-3 text-sm outline-none"
                  autoComplete={mode === "login" ? "current-password" : "new-password"}
                  required
                />
              </div>
            </label>

            {error && (
              <p className="rounded-xl border border-[rgba(175,74,98,0.65)] bg-[rgba(63,18,34,0.82)] px-3 py-2 text-sm text-rose-200">
                {error}
              </p>
            )}

            <Button variant="ritual" size="xl" className="mt-2 w-full rounded-xl" type="submit" disabled={loading}>
              {loading ? "Conectando..." : mode === "login" ? "Entrar al juego" : "Crear cuenta"}
            </Button>
          </form>
        </motion.div>
      </div>
    </div>
  );
}
