import { type PointerEvent, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Hand, HelpCircle, X } from "lucide-react";
import { FogBackground } from "../components/FogBackground";
import { Button } from "../components/Button";
import { PlayingCard } from "../components/Card";
import { ShadowMeter } from "../components/ShadowMeter";
import type { GameSettings } from "../types/game";
import { emitSfx } from "../audio/events";
import { triggerHaptic } from "../lib/haptics";

interface Props {
  settings: GameSettings;
  onComplete: () => void;
}

const tutorialSteps = [
  {
    title: "Introduccion",
    desc: "Objetivo: quedarte sin cartas antes que los demas.",
  },
  {
    title: "Palos y rango",
    desc: "Sangre, Ceniza, Hueso y Sombra. Se juega por palo o numero.",
  },
  {
    title: "Jugar carta",
    desc: "Arrastra la carta brillante hasta el centro. En movil no debe hacer scroll.",
  },
  {
    title: "Accion",
    desc: "Las acciones castigan al siguiente jugador y abren ventana de reaccion.",
  },
  {
    title: "Espejo Negro",
    desc: "Es una reaccion: devuelve el ataque al rival si la juegas a tiempo.",
  },
  {
    title: "Ritual + Shadow",
    desc: "Shadow es tu mana oscuro. Gastas Shadow para lanzar encantamientos.",
  },
  {
    title: "Eclipse",
    desc: "Con una carta restante debes cantar ECLIPSE para evitar penalizacion.",
  },
];

function speedFactor(speed: GameSettings["tutorialSpeed"]): number {
  if (speed === "fast") {
    return 0.7;
  }
  if (speed === "slow") {
    return 1.4;
  }
  return 1;
}

export function TutorialScreen({ settings, onComplete }: Props) {
  const [step, setStep] = useState(0);
  const [shadow, setShadow] = useState(0);
  const [reactionTimer, setReactionTimer] = useState(3);
  const [dragOffset, setDragOffset] = useState(0);
  const [isDraggingCard, setIsDraggingCard] = useState(false);
  const dragStartX = useRef<number | null>(null);

  const factor = useMemo(() => speedFactor(settings.tutorialSpeed), [settings.tutorialSpeed]);
  const reactionWindow = settings.tutorialSpeed === "slow" ? 4 : settings.tutorialSpeed === "fast" ? 2 : 3;

  useEffect(() => {
    if (step !== 4) return;

    setReactionTimer(reactionWindow);
    const interval = setInterval(() => {
      setReactionTimer((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setStep(5);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [step, reactionWindow]);

  useEffect(() => {
    setDragOffset(0);
    setIsDraggingCard(false);
    dragStartX.current = null;
  }, [step]);

  const handleNext = () => {
    if (step < tutorialSteps.length - 1) {
      setStep((prev) => prev + 1);
      return;
    }
    onComplete();
  };

  const handleContinue = () => {
    if (step === 2) {
      return;
    }
    if (step === 4) {
      setStep(5);
      return;
    }
    if (step === 5) {
      setStep(6);
      return;
    }
    handleNext();
  };

  const handleDragShadow = () => {
    if (step !== 2) return;
    emitSfx("card_play");
    triggerHaptic("tap");
    setShadow(1);
    window.setTimeout(() => setStep(3), Math.round(900 * factor));
  };

  const handleReaction = () => {
    if (step !== 4) {
      return;
    }
    emitSfx("reaction");
    triggerHaptic("success");
    setStep(5);
  };

  const handleRitual = () => {
    if (step !== 5) return;
    emitSfx("ritual");
    triggerHaptic("heavy");
    setShadow(0);
    window.setTimeout(() => setStep(6), Math.round(820 * factor));
  };

  const onCardPointerDown = (event: PointerEvent<HTMLDivElement>) => {
    if (step !== 2) {
      return;
    }
    event.preventDefault();
    dragStartX.current = event.clientX;
    setIsDraggingCard(true);
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const onCardPointerMove = (event: PointerEvent<HTMLDivElement>) => {
    if (step !== 2 || dragStartX.current === null) {
      return;
    }
    event.preventDefault();
    const delta = Math.max(0, event.clientX - dragStartX.current);
    setDragOffset(Math.min(delta, 130));
    if (delta > 110) {
      dragStartX.current = null;
      setDragOffset(0);
      setIsDraggingCard(false);
      handleDragShadow();
    }
  };

  const onCardPointerUp = () => {
    if (step !== 2) {
      return;
    }
    dragStartX.current = null;
    setDragOffset(0);
    setIsDraggingCard(false);
  };

  const continueLabel =
    step === tutorialSteps.length - 1
      ? "Finalizar tutorial"
      : step === 2
        ? "Desliza la carta para continuar"
        : step === 4
          ? "Continuar sin reaccion"
          : step === 5
            ? "Continuar sin ritual"
            : "Continuar";

  const contextualHelp =
    step === 4
      ? "Espejo Negro: devuelve el ataque al atacante. Si no reaccionas, recibes el castigo."
      : step === 5
        ? "Shadow = energia ritual. Con 2 puntos puedes activar ShadowSteal para drenar recurso rival."
        : "Arrastra la carta brillante hacia el centro para jugar tu turno.";

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden text-[var(--eclipse-text)]">
      <FogBackground className="opacity-85" />

      <div className="relative z-20 flex h-[100dvh] flex-col">
        <header className="flex items-center justify-between border-b border-[rgba(80,62,127,0.45)] px-4 py-4">
          <button
            onClick={onComplete}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-[rgba(85,67,136,0.7)] bg-[rgba(24,18,43,0.9)]"
          >
            <X className="h-4 w-4 text-[var(--eclipse-text)]" />
          </button>
          <h2 className="eclipse-title max-w-[58%] truncate text-sm sm:text-base">
            Tutorial: {tutorialSteps[step].title}
          </h2>
          <div className="rounded-lg border border-[rgba(85,67,136,0.65)] bg-[rgba(24,18,43,0.9)] px-2 py-1">
            <p className="eclipse-subtitle text-[10px]">{step + 1} / 7</p>
          </div>
        </header>

        <main
          className="eclipse-scrollbar flex-1 overflow-y-auto pb-36"
          style={{ touchAction: isDraggingCard ? "none" : "pan-y" }}
        >
          <div className="px-4 pt-4">
            <div className="relative overflow-hidden rounded-2xl border border-[rgba(89,69,143,0.62)] bg-[linear-gradient(180deg,rgba(33,21,60,0.95),rgba(15,10,28,0.98))] p-5">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(97,55,188,0.35),transparent_58%)]" />
              <div className="relative mx-auto flex w-fit flex-col items-center">
                <PlayingCard
                  suit={step >= 3 ? "ash" : "blood"}
                  rank={step >= 3 ? "9" : "7"}
                  className="!h-[8.5rem] !w-[6rem] sm:!h-40 sm:!w-28"
                  isPlayable={false}
                />
                <p className="eclipse-subtitle mt-3 rounded-full bg-[rgba(8,6,15,0.7)] px-3 py-1 text-[11px] text-[var(--eclipse-accent-soft)]">
                  Pila de descarte
                </p>
              </div>
              {step === 2 && (
                <motion.div
                  className="absolute right-[24%] top-10 text-white"
                  animate={{ y: [0, -10, 0], opacity: [0.6, 1, 0.6] }}
                  transition={{ duration: 1.6, repeat: Infinity }}
                >
                  <Hand className="h-11 w-11" />
                </motion.div>
              )}
            </div>
          </div>

          <div className="px-4 py-5 text-center">
            <h3 className="text-2xl font-extrabold leading-tight sm:text-4xl">Tu turno! Arrastra para jugar</h3>
            <p className="mt-2 text-base font-semibold leading-relaxed text-[var(--eclipse-accent-soft)] sm:text-2xl">
              {tutorialSteps[step].desc}
            </p>
          </div>

          {step === 1 && (
            <section className="mx-4 rounded-2xl border border-[rgba(93,71,151,0.58)] bg-[rgba(17,12,31,0.9)] p-4">
              <p className="eclipse-subtitle mb-3 text-[10px] text-[var(--eclipse-accent-soft)]">Ejemplos por palo</p>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div className="flex flex-col items-center gap-1.5">
                  <PlayingCard suit="blood" rank="4" className="!h-24 !w-[4.2rem]" />
                  <p className="text-[10px] eclipse-muted">Sangre 4</p>
                </div>
                <div className="flex flex-col items-center gap-1.5">
                  <PlayingCard suit="ash" rank="4" className="!h-24 !w-[4.2rem]" />
                  <p className="text-[10px] eclipse-muted">Ceniza 4</p>
                </div>
                <div className="flex flex-col items-center gap-1.5">
                  <PlayingCard suit="bone" rank="9" className="!h-24 !w-[4.2rem]" />
                  <p className="text-[10px] eclipse-muted">Hueso 9</p>
                </div>
                <div className="flex flex-col items-center gap-1.5">
                  <PlayingCard suit="shadow" rank="J" className="!h-24 !w-[4.2rem]" />
                  <p className="text-[10px] eclipse-muted">Sombra J (+1 Shadow)</p>
                </div>
              </div>
            </section>
          )}

          <AnimatePresence mode="wait">
            {step <= 3 && (
              <motion.section
                key={`hand-${step}`}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                className="eclipse-panel mx-4 rounded-t-3xl p-5"
              >
                <div className="flex justify-center gap-3 sm:gap-7">
                  <PlayingCard suit="ash" rank="3" className="rotate-[-7deg]" isPlayable={false} />
                  <motion.div
                    style={{ x: step === 2 ? dragOffset : 0, touchAction: step === 2 ? "none" : "auto" }}
                    onPointerDown={onCardPointerDown}
                    onPointerMove={onCardPointerMove}
                    onPointerUp={onCardPointerUp}
                    onPointerCancel={onCardPointerUp}
                  >
                    <PlayingCard
                      suit={step === 3 ? "action" : "blood"}
                      rank={step === 3 ? "ACCION" : "K"}
                      className="scale-105"
                      isPlayable={step === 2}
                      onClick={step === 2 ? handleDragShadow : undefined}
                    />
                  </motion.div>
                  <PlayingCard suit="ash" rank="5" className="rotate-[7deg]" isPlayable={false} />
                </div>
              </motion.section>
            )}

            {step === 4 && (
              <motion.section
                key="reaction-step"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                className="mx-4 rounded-2xl border border-[rgba(196,83,121,0.6)] bg-[linear-gradient(180deg,rgba(52,22,40,0.95),rgba(26,12,20,0.98))] p-5"
              >
                <p className="eclipse-subtitle text-center text-[11px] text-rose-300">
                  Ventana de reaccion: usa Espejo Negro
                </p>
                <div className="my-4 flex justify-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-rose-400 text-2xl font-bold sm:h-20 sm:w-20 sm:text-3xl">
                    {reactionTimer}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Button variant="ritual" size="lg" className="rounded-xl" onClick={handleReaction}>
                    Espejo negro
                  </Button>
                  <Button variant="secondary" size="lg" className="rounded-xl" onClick={() => setStep(5)}>
                    Pasar
                  </Button>
                </div>
              </motion.section>
            )}

            {step === 5 && (
              <motion.section
                key="ritual-step"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                className="mx-4 flex items-center justify-center gap-5 rounded-2xl border border-[rgba(98,74,166,0.6)] bg-[rgba(24,18,42,0.95)] p-5"
              >
                <ShadowMeter value={Math.max(shadow, 2)} />
                <div>
                  <PlayingCard suit="ritual" rank="RITUAL" cost={2} isPlayable onClick={handleRitual} />
                  <p className="eclipse-subtitle mt-2 text-center text-[10px] text-[var(--eclipse-accent-soft)]">
                    Toca para lanzar ShadowSteal
                  </p>
                </div>
              </motion.section>
            )}

            {step === 6 && (
              <motion.section
                key="eclipse-step"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                className="mx-4 flex flex-col items-center rounded-2xl border border-[rgba(175,70,84,0.62)] bg-[rgba(51,15,22,0.92)] p-7"
              >
                <Button
                  variant="danger"
                  size="xl"
                  className="h-28 w-28 rounded-full text-xl shadow-[0_0_35px_rgba(218,69,92,0.55)] sm:h-32 sm:w-32 sm:text-2xl"
                  onClick={() => {
                    emitSfx("eclipse_call");
                    handleNext();
                  }}
                >
                  Eclipse
                </Button>
                <p className="mt-4 max-w-xs text-center text-sm eclipse-muted sm:text-lg">
                  Pulsa Eclipse al tener 1 carta para no robar penalizacion.
                </p>
              </motion.section>
            )}
          </AnimatePresence>

          <div className="mx-4 mt-4 rounded-2xl border border-[rgba(88,69,139,0.4)] bg-[rgba(24,18,42,0.88)] p-4">
            <div className="flex items-start gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[rgba(139,92,246,0.25)]">
                <HelpCircle className="h-6 w-6 text-[var(--eclipse-accent-soft)]" />
              </div>
              <div>
                <p className="text-lg font-bold sm:text-2xl">Como funciona?</p>
                <p className="mt-1 text-sm leading-relaxed eclipse-muted sm:text-lg">{contextualHelp}</p>
              </div>
            </div>
          </div>
        </main>

        <div className="pointer-events-none absolute inset-x-0 bottom-0 z-30 px-4 pb-[calc(0.9rem+env(safe-area-inset-bottom))]">
          <div className="pointer-events-auto rounded-2xl border border-[rgba(115,87,190,0.4)] bg-[linear-gradient(180deg,rgba(7,7,10,0.82),rgba(5,5,8,0.94))] p-2 backdrop-blur-xl">
            <Button
              variant="primary"
              size="xl"
              className="w-full rounded-xl"
              onClick={handleContinue}
              disabled={step === 2}
            >
              {continueLabel}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
