import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Button } from "../components/Button";
import { Avatar } from "../components/Avatar";
import { FogBackground } from "../components/FogBackground";
import { OverlayPanel } from "../components/OverlayPanel";
import { SettingsControls } from "../components/SettingsControls";
import type { GameSettings } from "../types/game";
import {
  ArrowLeft,
  Crown,
  Plus,
  Settings2,
  ShieldCheck,
  UserPlus2,
  Users,
  X,
} from "lucide-react";

interface Props {
  hostName: string;
  settings: GameSettings;
  onSettingsChange: (patch: Partial<GameSettings>) => void;
  onBack: () => void;
  onStart: () => void;
}

type LobbyPlayer = {
  id: number;
  name: string;
  role: string;
  isReady: boolean;
  type: "human" | "bot";
};

type LobbyTab = "sala" | "heroes" | "social" | "inventario";

export function LobbyScreen({ hostName, settings, onSettingsChange, onBack, onStart }: Props) {
  const [players, setPlayers] = useState<LobbyPlayer[]>([
    { id: 1, name: hostName, role: "Invocador", isReady: true, type: "human" },
    { id: 2, name: "Bot_01", role: "Minion Cruel", isReady: true, type: "bot" },
  ]);
  const [tab, setTab] = useState<LobbyTab>("sala");
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    setPlayers((prev) =>
      prev.map((player, index) => {
        if (index !== 0 || player.type !== "human") {
          return player;
        }
        return {
          ...player,
          name: hostName,
        };
      }),
    );
  }, [hostName]);

  const maxPlayers = 6;
  const readyCount = players.filter((p) => p.isReady).length;
  const slotsLeft = maxPlayers - players.length;
  const canStart = useMemo(() => players.length >= 3 && readyCount === players.length, [players, readyCount]);

  const addBot = () => {
    if (players.length >= maxPlayers) return;
    const index = players.filter((p) => p.type === "bot").length + 2;
    setPlayers((prev) => [
      ...prev,
      {
        id: Date.now(),
        name: `Bot_${String(index).padStart(2, "0")}`,
        role: "Minion Cruel",
        isReady: true,
        type: "bot",
      },
    ]);
  };

  const removeBot = (id: number) => {
    setPlayers((prev) => prev.filter((p) => p.id !== id));
  };

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden text-[var(--eclipse-text)]">
      <FogBackground className="opacity-80" />

      <div className="relative z-20 flex h-[100dvh] flex-col">
        <header className="flex items-center justify-between border-b border-[rgba(78,61,126,0.45)] px-4 py-4">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onBack}
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-[rgba(85,67,136,0.7)] bg-[rgba(24,18,43,0.9)]"
            >
              <ArrowLeft className="h-4 w-4 text-[var(--eclipse-text)]" />
            </button>
            <div>
              <p className="eclipse-subtitle text-[10px] text-[var(--eclipse-accent-soft)]">Nexus Arcano</p>
              <h1 className="eclipse-title text-lg sm:text-xl">Configuracion de sala</h1>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowSettings(true)}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-[rgba(85,67,136,0.7)] bg-[rgba(24,18,43,0.9)]"
          >
            <Settings2 className="h-4 w-4 text-[var(--eclipse-text-muted)]" />
          </button>
        </header>

        <div className="flex items-center justify-between border-b border-[rgba(78,61,126,0.35)] px-4 py-3">
          <div>
            <p className="eclipse-title text-base sm:text-lg">Sala</p>
            <p className="eclipse-subtitle text-[9px] sm:text-[10px] eclipse-faint">
              {slotsLeft} slots disponibles - modo competitivo
            </p>
          </div>
          <div className="rounded-xl border border-[rgba(90,167,120,0.45)] bg-[rgba(22,36,32,0.9)] px-3 py-2">
            <p className="flex items-center gap-2 text-xs font-semibold text-emerald-300 sm:text-sm">
              <Users className="h-4 w-4" />
              {players.length} / {maxPlayers} jugadores
            </p>
          </div>
        </div>

        <main className="eclipse-scrollbar flex-1 overflow-y-auto overscroll-contain px-3 pb-[calc(8rem+env(safe-area-inset-bottom))] pt-3">
          {tab === "sala" && (
            <div className="space-y-3">
              <AnimatePresence mode="popLayout">
                {players.map((player) => (
                  <motion.div
                    key={player.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="eclipse-panel rounded-2xl p-3"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar
                        name={player.name}
                        role={player.role}
                        className="!flex-row !items-center !gap-3 [&>div:nth-child(2)]:text-left"
                      />
                      <div className="ml-auto flex items-center gap-2">
                        <div className="rounded-full border border-[rgba(89,69,143,0.7)] bg-[rgba(27,20,49,0.9)] px-2 py-1">
                          <p className="eclipse-subtitle text-[9px] text-[var(--eclipse-accent-soft)]">
                            {player.type === "human" ? "Host" : "Bot"}
                          </p>
                        </div>
                        {player.isReady && (
                          <div className="flex items-center gap-1 rounded-full border border-[rgba(67,142,100,0.6)] bg-[rgba(20,36,32,0.88)] px-2 py-1">
                            <ShieldCheck className="h-3.5 w-3.5 text-emerald-300" />
                            <span className="eclipse-subtitle text-[9px] text-emerald-300">Listo</span>
                          </div>
                        )}
                        {player.type === "bot" && (
                          <button
                            type="button"
                            onClick={() => removeBot(player.id)}
                            className="flex h-7 w-7 items-center justify-center rounded-full border border-[rgba(175,73,98,0.7)] bg-[rgba(62,18,33,0.9)] text-rose-200"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              <div className="eclipse-panel rounded-2xl p-4">
                <div className="mb-3 flex items-center gap-2">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[rgba(120,76,220,0.16)] text-[var(--eclipse-accent-soft)]">
                    <Crown className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="font-semibold">Configurar bot</p>
                    <p className="eclipse-subtitle text-[10px] eclipse-faint">Slot vacio</p>
                  </div>
                </div>
                <Button
                  variant="ritual"
                  size="lg"
                  className="w-full rounded-xl"
                  onClick={addBot}
                  disabled={players.length >= maxPlayers}
                >
                  <Plus className="h-4 w-4" />
                  Anadir bot
                </Button>
              </div>

              <div className="eclipse-panel rounded-2xl p-4">
                <p className="eclipse-title mb-2 text-base">Requisitos de partida</p>
                <div className="mb-4 flex flex-wrap items-center gap-3 text-sm eclipse-muted">
                  <span className="flex items-center gap-1 text-emerald-300">
                    <span className="h-2 w-2 rounded-full bg-emerald-400" />
                    Minimo 2 jugadores
                  </span>
                  <span className="flex items-center gap-1 text-emerald-300">
                    <span className="h-2 w-2 rounded-full bg-emerald-400" />
                    Todos listos
                  </span>
                </div>
                <Button
                  variant="ritual"
                  size="xl"
                  className="w-full rounded-xl text-lg italic"
                  disabled={!canStart}
                  onClick={onStart}
                >
                  Empezar
                </Button>
              </div>
            </div>
          )}

          {tab === "heroes" && (
            <section className="eclipse-panel space-y-4 rounded-2xl p-4">
              <h2 className="eclipse-title text-sm">Arquetipos disponibles</h2>
              <div className="grid gap-3 text-sm">
                <div className="rounded-xl border border-[rgba(88,68,140,0.6)] bg-[rgba(15,12,28,0.86)] p-3">
                  <p className="font-semibold">Oraculo</p>
                  <p className="mt-1 eclipse-muted">Controla el ritmo de turno y fuerza robos.</p>
                </div>
                <div className="rounded-xl border border-[rgba(88,68,140,0.6)] bg-[rgba(15,12,28,0.86)] p-3">
                  <p className="font-semibold">Minion Cruel</p>
                  <p className="mt-1 eclipse-muted">Presiona con acciones directas y castigo.</p>
                </div>
                <div className="rounded-xl border border-[rgba(88,68,140,0.6)] bg-[rgba(15,12,28,0.86)] p-3">
                  <p className="font-semibold">Adepto Cobarde</p>
                  <p className="mt-1 eclipse-muted">Ahorra reacciones para defenderse tarde.</p>
                </div>
              </div>
            </section>
          )}

          {tab === "social" && (
            <section className="space-y-3">
              <div className="eclipse-panel rounded-2xl p-4">
                <h2 className="eclipse-title mb-2 text-sm">Invitaciones</h2>
                <p className="text-sm eclipse-muted">
                  Comparte el codigo de sala para que entren tus compañeros de club.
                </p>
                <div className="mt-3 rounded-xl border border-[rgba(95,71,153,0.7)] bg-[rgba(16,12,30,0.9)] px-3 py-2 text-center text-lg tracking-[0.2em]">
                  ECPL-7K2M
                </div>
              </div>
              {Array.from({ length: Math.max(0, slotsLeft) }).map((_, idx) => (
                <div
                  key={idx}
                  className="eclipse-panel-soft flex h-20 items-center justify-center rounded-2xl border-dashed text-[var(--eclipse-text-faint)]"
                >
                  <div className="flex items-center gap-2 text-sm uppercase tracking-[0.14em]">
                    <UserPlus2 className="h-4 w-4" />
                    Esperando jugador...
                  </div>
                </div>
              ))}
            </section>
          )}

          {tab === "inventario" && (
            <section className="eclipse-panel space-y-4 rounded-2xl p-4">
              <h2 className="eclipse-title text-sm">Inventario ritual</h2>
              <div className="grid gap-3 text-sm">
                <div className="rounded-xl border border-[rgba(88,68,140,0.6)] bg-[rgba(15,12,28,0.86)] p-3">
                  <p className="font-semibold">Mazo activo</p>
                  <p className="mt-1 eclipse-muted">Sombra / Ceniza</p>
                </div>
                <div className="rounded-xl border border-[rgba(88,68,140,0.6)] bg-[rgba(15,12,28,0.86)] p-3">
                  <p className="font-semibold">Reliquia</p>
                  <p className="mt-1 eclipse-muted">Espejo Negro +1 reaccion</p>
                </div>
                <div className="rounded-xl border border-[rgba(88,68,140,0.6)] bg-[rgba(15,12,28,0.86)] p-3">
                  <p className="font-semibold">Estandarte</p>
                  <p className="mt-1 eclipse-muted">Eclipse de oro</p>
                </div>
              </div>
            </section>
          )}
        </main>

        <nav className="fixed inset-x-0 bottom-0 z-30">
          <div className="eclipse-bottom-nav grid grid-cols-4 px-4 pb-[calc(1.25rem+env(safe-area-inset-bottom))] pt-3">
            <button
              type="button"
              onClick={() => setTab("sala")}
              className={`flex flex-col items-center gap-1 ${tab === "sala" ? "text-[var(--eclipse-accent-soft)]" : "text-[var(--eclipse-text-faint)]"}`}
            >
              <Users className="h-5 w-5" />
              <span className="eclipse-subtitle text-[9px]">Sala</span>
            </button>
            <button
              type="button"
              onClick={() => setTab("heroes")}
              className={`flex flex-col items-center gap-1 ${tab === "heroes" ? "text-[var(--eclipse-accent-soft)]" : "text-[var(--eclipse-text-faint)]"}`}
            >
              <Crown className="h-5 w-5" />
              <span className="eclipse-subtitle text-[9px]">Heroes</span>
            </button>
            <button
              type="button"
              onClick={() => setTab("social")}
              className={`flex flex-col items-center gap-1 ${tab === "social" ? "text-[var(--eclipse-accent-soft)]" : "text-[var(--eclipse-text-faint)]"}`}
            >
              <UserPlus2 className="h-5 w-5" />
              <span className="eclipse-subtitle text-[9px]">Social</span>
            </button>
            <button
              type="button"
              onClick={() => setTab("inventario")}
              className={`flex flex-col items-center gap-1 ${tab === "inventario" ? "text-[var(--eclipse-accent-soft)]" : "text-[var(--eclipse-text-faint)]"}`}
            >
              <Settings2 className="h-5 w-5" />
              <span className="eclipse-subtitle text-[9px]">Inventario</span>
            </button>
          </div>
        </nav>
      </div>

      <OverlayPanel open={showSettings} onClose={() => setShowSettings(false)} title="Ajustes de sala">
        <SettingsControls settings={settings} onChange={onSettingsChange} showTutorialSpeed />
        <div className="mt-3">
          <Button variant="secondary" size="md" className="w-full rounded-xl" onClick={() => setShowSettings(false)}>
            Cerrar
          </Button>
        </div>
      </OverlayPanel>
    </div>
  );
}
