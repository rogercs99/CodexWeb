import { useState } from "react";
import { motion } from "motion/react";
import { FogBackground } from "../components/FogBackground";
import { Button } from "../components/Button";
import { OverlayPanel } from "../components/OverlayPanel";
import { CircleHelp, Home, Sparkles, Swords, SunMedium, User } from "lucide-react";
import type { AuthUser } from "../lib/api";

interface Props {
  user: AuthUser;
  onStartTutorial: () => void;
  onSkip: () => void;
}

export function WelcomeScreen({ user, onStartTutorial, onSkip }: Props) {
  const [showHelp, setShowHelp] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [activeNav, setActiveNav] = useState<"home" | "tutorial" | "menu" | "profile">("home");

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden text-[var(--eclipse-text)] font-sans">
      <FogBackground />

      <div className="relative z-20 flex h-[100dvh] flex-col">
        <header className="flex items-center justify-between px-6 pt-6 sm:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full border border-[rgba(200,154,23,0.45)] bg-[rgba(200,154,23,0.1)]">
              <SunMedium className="h-4 w-4 text-[var(--eclipse-gold)]" />
            </div>
            <p className="eclipse-title text-xl tracking-[0.24em]">Eclipse Club</p>
          </div>
          <button
            type="button"
            onClick={() => setShowHelp(true)}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-[rgba(200,154,23,0.78)] text-[#22112f] transition-transform hover:scale-105"
          >
            <CircleHelp className="h-4 w-4" />
          </button>
        </header>

        <main className="flex flex-1 flex-col items-center justify-center px-6 pt-6 text-center sm:px-8">
          <motion.div
            className="relative mb-10 flex h-40 w-40 items-center justify-center rounded-full border border-[rgba(200,154,23,0.28)] eclipse-crown-glow sm:h-52 sm:w-52"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8 }}
          >
            <motion.div
              className="absolute inset-3 rounded-full border border-[rgba(200,154,23,0.16)]"
              animate={{ rotate: 360 }}
              transition={{ duration: 45, repeat: Infinity, ease: "linear" }}
            />
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-[rgba(200,154,23,0.14)] sm:h-24 sm:w-24">
              <SunMedium className="h-11 w-11 text-[var(--eclipse-gold)] sm:h-12 sm:w-12" />
            </div>
          </motion.div>

          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.15, duration: 0.7 }}
            className="max-w-sm"
          >
            <h1 className="text-3xl font-extrabold tracking-tight sm:text-5xl">
              Aprende jugando.
            </h1>
            <p className="eclipse-subtitle mt-2 text-2xl text-[var(--eclipse-gold)] sm:text-4xl">
              90 segundos.
            </p>
            <p className="mt-4 text-sm leading-relaxed eclipse-muted sm:text-lg">
              Domina el conocimiento arcano en sesiones rapidas de alta intensidad.
            </p>
          </motion.div>
        </main>

        <footer className="z-20 px-6 pb-[calc(6.5rem+env(safe-area-inset-bottom))] sm:px-8 sm:pb-28">
          <div className="mx-auto flex w-full max-w-md flex-col gap-3">
            <Button
              variant="primary"
              size="xl"
              onClick={() => {
                setActiveNav("tutorial");
                onStartTutorial();
              }}
              className="w-full rounded-2xl"
            >
              <Swords className="h-5 w-5 text-[var(--eclipse-gold)]" />
              Iniciar tutorial
            </Button>
            <Button
              variant="ghost"
              size="md"
              onClick={() => {
                setActiveNav("menu");
                onSkip();
              }}
              className="w-full rounded-xl text-[var(--eclipse-text-muted)]"
            >
              Omitir (hacer mas tarde)
            </Button>
          </div>
        </footer>

        <nav className="fixed inset-x-0 bottom-0 z-30">
          <div className="eclipse-bottom-nav flex items-center justify-around px-4 pb-[calc(1.25rem+env(safe-area-inset-bottom))] pt-3">
            <button
              type="button"
              onClick={() => setActiveNav("home")}
              className={activeNav === "home" ? "text-[var(--eclipse-gold)]" : "text-[var(--eclipse-text-faint)]"}
            >
              <Home className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveNav("tutorial");
                onStartTutorial();
              }}
              className={activeNav === "tutorial" ? "text-[var(--eclipse-gold)]" : "text-[var(--eclipse-text-faint)]"}
            >
              <Swords className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveNav("menu");
                onSkip();
              }}
              className={activeNav === "menu" ? "text-[var(--eclipse-gold)]" : "text-[var(--eclipse-text-faint)]"}
            >
              <Sparkles className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveNav("profile");
                setShowProfile(true);
              }}
              className={activeNav === "profile" ? "text-[var(--eclipse-gold)]" : "text-[var(--eclipse-text-faint)]"}
            >
              <User className="h-5 w-5" />
            </button>
          </div>
        </nav>
      </div>

      <motion.div
        className="pointer-events-none absolute -left-20 top-1/2 h-32 w-32 -translate-y-1/2 rotate-12 bg-[rgba(200,154,23,0.08)] blur-2xl"
        animate={{ x: [0, 25, 0], opacity: [0.2, 0.35, 0.2] }}
        transition={{ duration: 8, repeat: Infinity }}
      />

      <OverlayPanel open={showHelp} onClose={() => setShowHelp(false)} title="Guia Rapida">
        <p className="text-sm leading-relaxed eclipse-muted">
          Juega una carta por turno, activa reacciones cuando te ataquen y recuerda pulsar ECLIPSE
          al quedarte con una sola carta.
        </p>
        <div className="mt-4 grid gap-2">
          <Button
            variant="primary"
            size="md"
            className="rounded-xl"
            onClick={() => {
              setShowHelp(false);
              onStartTutorial();
            }}
          >
            Empezar tutorial
          </Button>
          <Button variant="secondary" size="md" className="rounded-xl" onClick={() => setShowHelp(false)}>
            Cerrar
          </Button>
        </div>
      </OverlayPanel>

      <OverlayPanel open={showProfile} onClose={() => setShowProfile(false)} title="Perfil Temporal">
        <div className="space-y-3 text-sm">
          <p className="font-semibold">{user.displayName}</p>
          <p className="eclipse-muted">Nivel: {user.level}</p>
          <p className="eclipse-muted">XP: {user.xp}</p>
          <p className="eclipse-muted">Partidas: {user.matches}</p>
          <p className="eclipse-muted">Victorias: {user.wins}</p>
          <Button variant="secondary" size="md" className="w-full rounded-xl" onClick={() => setShowProfile(false)}>
            Volver
          </Button>
        </div>
      </OverlayPanel>
    </div>
  );
}
