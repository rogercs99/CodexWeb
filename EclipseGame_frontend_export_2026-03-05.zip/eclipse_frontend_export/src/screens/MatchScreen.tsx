import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Menu, MessageSquare, Settings, SunMoon } from "lucide-react";
import { FogBackground } from "../components/FogBackground";
import { Button } from "../components/Button";
import { PlayingCard } from "../components/Card";
import { Avatar } from "../components/Avatar";
import { ShadowMeter } from "../components/ShadowMeter";
import { OverlayPanel } from "../components/OverlayPanel";
import { SettingsControls } from "../components/SettingsControls";
import type { GameSettings } from "../types/game";
import { emitSfx } from "../audio/events";
import { triggerHaptic } from "../lib/haptics";

interface Props {
  settings: GameSettings;
  onSettingsChange: (patch: Partial<GameSettings>) => void;
  onExit: () => void;
}

export function MatchScreen({ settings, onSettingsChange, onExit }: Props) {
  const [turn, setTurn] = useState(0);
  const [showEclipseButton, setShowEclipseButton] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [centerCard, setCenterCard] = useState({ suit: "blood", rank: "7" });
  const [userHand, setUserHand] = useState([
    { suit: "blood", rank: "4", isPlayable: true },
    { suit: "ash", rank: "3", isPlayable: false },
    { suit: "shadow", rank: "J", isPlayable: false },
    { suit: "bone", rank: "A", isPlayable: false },
    { suit: "ritual", rank: "RITUAL", cost: 2, isPlayable: false },
  ]);
  const [shadow, setShadow] = useState(0);
  const [message, setMessage] = useState("Tu turno.");

  const handlePlayCard = (index: number) => {
    if (turn !== 0 || !userHand[index].isPlayable) return;

    const card = userHand[index];
    emitSfx(card.suit === "ritual" ? "ritual" : "card_play");
    triggerHaptic(card.suit === "ritual" ? "heavy" : "tap");
    setCenterCard({ suit: card.suit, rank: card.rank });
    const nextHand = [...userHand];
    nextHand.splice(index, 1);
    setUserHand(nextHand);

    setShadow((prev) => Math.min(prev + (card.suit === "shadow" ? 1 : 0), 6));
    setTurn(1);
    setMessage("Turno del Esbirro.");

    if (nextHand.length === 1) {
      setShowEclipseButton(true);
    }

    setTimeout(() => {
      emitSfx("draw");
      setTurn(2);
      setMessage("Turno del Adepto.");
      setCenterCard({ suit: "ash", rank: "9" });

      setTimeout(() => {
        emitSfx("draw");
        setTurn(3);
        setMessage("Turno del Oraculo.");
        setCenterCard({ suit: "shadow", rank: "2" });

        setTimeout(() => {
          setTurn(0);
          setMessage("Tu turno.");
          setUserHand((prev) =>
            prev.map((c) => ({
              ...c,
              isPlayable:
                c.suit === "shadow" || c.rank === "2" || c.suit === "ritual",
            })),
          );
        }, 1800);
      }, 1800);
    }, 1800);
  };

  const handleEclipse = () => {
    emitSfx("eclipse_call");
    triggerHaptic("heavy");
    setShowEclipseButton(false);
    setMessage("ECLIPSE! Sigues protegido.");
  };

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden text-[var(--eclipse-text)]">
      <FogBackground className="opacity-82" />

      <div className="relative z-20 flex h-[100dvh] flex-col">
        <header className="flex items-center justify-between border-b border-[rgba(80,62,127,0.45)] px-4 py-3">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="rounded-lg" onClick={onExit}>
              <Menu className="h-4 w-4" />
            </Button>
            <h2 className="eclipse-title text-sm sm:text-base">Mesa de Sombras</h2>
          </div>
          <div className="flex items-center gap-2">
            <div className="rounded-lg border border-[rgba(84,66,137,0.75)] bg-[rgba(24,18,43,0.9)] px-2 py-1">
              <p className="eclipse-subtitle text-[10px]">Ronda 12</p>
            </div>
            <Button variant="ghost" size="sm" className="rounded-lg" onClick={() => setShowChat(true)}>
              <MessageSquare className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="rounded-lg" onClick={() => setShowSettings(true)}>
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </header>

        <div className="grid grid-cols-[80px_1fr_52px] gap-2 px-2 pb-[calc(8rem+env(safe-area-inset-bottom))] pt-2 sm:grid-cols-[88px_1fr_62px] sm:pb-32">
          <aside className="space-y-4 pt-1">
            <Avatar name="Lysandra" cardCount={4} isTurn={turn === 1} className="scale-90" />
            <Avatar name="Valerius" cardCount={3} isTurn={turn === 2} className="scale-90" />
            <Avatar name="Morgraith" cardCount={5} isTurn={turn === 3} className="scale-90" />
          </aside>

          <main className="relative flex h-[calc(100dvh-220px)] flex-col">
            <div className="relative flex flex-1 items-center justify-center rounded-2xl border border-[rgba(81,64,130,0.45)] bg-[rgba(10,8,18,0.45)]">
              <div className="absolute left-[18%] top-1/2 -translate-y-1/2">
                <div className="relative">
                  <PlayingCard suit="ash" rank="1" isFaceDown />
                  <p className="eclipse-subtitle absolute -bottom-4 left-1/2 -translate-x-1/2 rounded-full border border-[rgba(85,67,136,0.7)] bg-[rgba(24,18,43,0.9)] px-2 py-0.5 text-[10px]">
                    24
                  </p>
                </div>
              </div>

              <motion.div
                key={`${centerCard.suit}-${centerCard.rank}`}
                initial={{ scale: 0.8, opacity: 0, rotate: -12 }}
                animate={{ scale: 1, opacity: 1, rotate: (Math.random() - 0.5) * 4 }}
                className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
              >
                <PlayingCard suit={centerCard.suit as any} rank={centerCard.rank as any} />
              </motion.div>

              <div className="absolute right-[12%] top-[14%] text-[var(--eclipse-text-faint)]">
                <SunMoon className="h-6 w-6" />
              </div>
            </div>

            <motion.div
              key={message}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mx-auto mt-3 w-full max-w-xl rounded-xl border border-[rgba(87,70,141,0.58)] bg-[rgba(25,19,46,0.9)] px-4 py-2"
            >
              <p className="text-center text-xs font-semibold tracking-[0.08em] sm:text-sm">{message}</p>
            </motion.div>
          </main>

          <div className="flex items-start justify-center pt-8">
            <ShadowMeter value={shadow} orientation="vertical" />
          </div>
        </div>

        <AnimatePresence>
          {showEclipseButton && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="absolute bottom-40 left-1/2 z-40 -translate-x-1/2"
            >
              <Button
                variant="danger"
                size="xl"
                className="h-24 w-32 rounded-2xl text-3xl italic shadow-[0_0_30px_rgba(218,69,92,0.55)]"
                onClick={handleEclipse}
              >
                Eclipse!
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="absolute inset-x-0 bottom-0 z-30 pb-[calc(1rem+env(safe-area-inset-bottom))] sm:pb-5">
          <div className="mx-auto max-w-4xl px-4">
            <div className="mb-2 flex justify-center">
              <span className="eclipse-subtitle rounded-full border border-[rgba(200,154,23,0.5)] bg-[rgba(22,16,40,0.9)] px-5 py-1 text-[10px] text-[var(--eclipse-gold)]">
                Tu mano
              </span>
            </div>

            <div className="flex items-end justify-center gap-2">
              <Avatar name="Tu" isTurn={turn === 0} />
              <div className="eclipse-scrollbar flex flex-1 items-end justify-start gap-2 overflow-x-auto pb-1 pr-1">
                <AnimatePresence>
                  {userHand.map((card, i) => {
                    return (
                      <motion.div
                        key={`${card.suit}-${card.rank}-${i}`}
                        initial={{ y: 100, opacity: 0 }}
                        animate={{ y: 0, opacity: 1, rotate: 0 }}
                        exit={{ y: 100, opacity: 0, scale: 0.7 }}
                        className="relative"
                        style={{ zIndex: i + 10 }}
                      >
                        <PlayingCard
                          suit={card.suit as any}
                          rank={card.rank as any}
                          cost={card.cost}
                          className="min-w-[5.5rem]"
                          isPlayable={card.isPlayable && turn === 0}
                          onClick={() => handlePlayCard(i)}
                        />
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>
      </div>

      <OverlayPanel open={showChat} onClose={() => setShowChat(false)} title="Chat de mesa">
        <div className="space-y-2 text-sm">
          <p className="rounded-xl border border-[rgba(87,67,139,0.6)] bg-[rgba(18,13,32,0.9)] px-3 py-2">
            Lysandra: Tengo reaccion preparada.
          </p>
          <p className="rounded-xl border border-[rgba(87,67,139,0.6)] bg-[rgba(18,13,32,0.9)] px-3 py-2">
            Tu: Voy con ritual al proximo turno.
          </p>
          <Button variant="secondary" size="md" className="w-full rounded-xl" onClick={() => setShowChat(false)}>
            Cerrar chat
          </Button>
        </div>
      </OverlayPanel>

      <OverlayPanel open={showSettings} onClose={() => setShowSettings(false)} title="Opciones de partida">
        <SettingsControls settings={settings} onChange={onSettingsChange} showTutorialSpeed />
        <div className="mt-3">
          <Button variant="secondary" size="md" className="w-full rounded-xl" onClick={() => setShowSettings(false)}>
            Cerrar
          </Button>
        </div>
      </OverlayPanel>
    </div>
  );
}
