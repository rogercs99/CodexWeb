import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Menu, Settings, SunMoon } from "lucide-react";
import { FogBackground } from "../components/FogBackground";
import { Button } from "../components/Button";
import { PlayingCard } from "../components/Card";
import { Avatar } from "../components/Avatar";
import { ShadowMeter } from "../components/ShadowMeter";
import { OverlayPanel } from "../components/OverlayPanel";
import { SettingsControls } from "../components/SettingsControls";
import type { GameSettings } from "../types/game";
import { emitSfx } from "../audio/events";
import { triggerHaptic } from "../lib/haptics";

interface Props {
  settings: GameSettings;
  onSettingsChange: (patch: Partial<GameSettings>) => void;
  onComplete: () => void;
}

function tutorialPace(speed: GameSettings["tutorialSpeed"]): number {
  if (speed === "fast") {
    return 0.65;
  }
  if (speed === "slow") {
    return 1.35;
  }
  return 1;
}

export function DemoMatchScreen({ settings, onSettingsChange, onComplete }: Props) {
  const [turn, setTurn] = useState(0);
  const [showEclipseButton, setShowEclipseButton] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [centerCard, setCenterCard] = useState({ suit: "blood", rank: "7" });
  const [userHand, setUserHand] = useState([
    { suit: "blood", rank: "4", isPlayable: true },
    { suit: "ash", rank: "3", isPlayable: false },
    { suit: "shadow", rank: "J", isPlayable: false },
  ]);
  const [message, setMessage] = useState("Tu turno. Juega Sangre 4.");

  useEffect(() => {
    const pace = tutorialPace(settings.tutorialSpeed);

    if (turn === 1) {
      setMessage("El Esbirro juega Accion. Debes reaccionar.");
      emitSfx("reaction");
      setTimeout(() => setTurn(2), Math.round(1800 * pace));
    } else if (turn === 2) {
      setMessage("El Adepto olvida decir Eclipse. +2 cartas.");
      emitSfx("draw");
      setTimeout(() => setTurn(3), Math.round(2500 * pace));
    } else if (turn === 3) {
      setMessage("Tu turno. Juega Ceniza 3.");
      setUserHand([
        { suit: "ash", rank: "3", isPlayable: true },
        { suit: "shadow", rank: "J", isPlayable: false },
      ]);
      setCenterCard({ suit: "ash", rank: "9" });
    } else if (turn === 4) {
      setMessage("El Oraculo pasa.");
      setTimeout(() => setTurn(5), Math.round(1500 * pace));
    } else if (turn === 5) {
      setMessage("Tu turno. Presiona ECLIPSE y juega Sombra J.");
      setUserHand([{ suit: "shadow", rank: "J", isPlayable: true }]);
      setCenterCard({ suit: "shadow", rank: "2" });
      setShowEclipseButton(true);
    } else if (turn === 6) {
      setMessage("Has ganado!");
      setTimeout(onComplete, Math.round(2200 * pace));
    }
  }, [turn, settings.tutorialSpeed, onComplete]);

  const handlePlayCard = (index: number) => {
    if (turn === 0 && index === 0) {
      emitSfx("card_play");
      triggerHaptic("tap");
      setCenterCard({ suit: "blood", rank: "4" });
      setUserHand([
        { suit: "ash", rank: "3", isPlayable: false },
        { suit: "shadow", rank: "J", isPlayable: false },
      ]);
      setTurn(1);
      return;
    }
    if (turn === 3 && index === 0) {
      emitSfx("card_play");
      triggerHaptic("tap");
      setCenterCard({ suit: "ash", rank: "3" });
      setUserHand([{ suit: "shadow", rank: "J", isPlayable: false }]);
      setTurn(4);
      return;
    }
    if (turn === 5 && index === 0) {
      if (showEclipseButton) {
        setMessage("Presiona ECLIPSE primero.");
        return;
      }
      emitSfx("card_play");
      triggerHaptic("tap");
      setCenterCard({ suit: "shadow", rank: "J" });
      setUserHand([]);
      setTurn(6);
    }
  };

  const handleEclipse = () => {
    emitSfx("eclipse_call");
    triggerHaptic("heavy");
    setShowEclipseButton(false);
    setMessage("ECLIPSE! Ahora juega tu ultima carta.");
  };

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden text-[var(--eclipse-text)]">
      <FogBackground className="opacity-80" />

      <div className="relative z-20 flex h-[100dvh] flex-col">
        <header className="flex items-center justify-between border-b border-[rgba(80,62,127,0.45)] px-4 py-3">
          <Button variant="ghost" size="sm" className="rounded-lg" onClick={onComplete}>
            <Menu className="h-4 w-4" />
          </Button>
          <div className="rounded-xl border border-[rgba(84,66,137,0.75)] bg-[rgba(24,18,43,0.9)] px-3 py-1.5">
            <p className="eclipse-subtitle text-[10px]">Partida de practica</p>
          </div>
          <Button variant="ghost" size="sm" className="rounded-lg" onClick={() => setShowSettings(true)}>
            <Settings className="h-4 w-4" />
          </Button>
        </header>

        <div className="grid grid-cols-[80px_1fr_52px] gap-2 px-2 pb-[calc(7.5rem+env(safe-area-inset-bottom))] pt-3 sm:grid-cols-[84px_1fr_56px] sm:pb-28">
          <div className="space-y-5 pt-2">
            <Avatar name="Esbirro" role="Cruel" cardCount={4} isTurn={turn === 1} className="scale-90" />
            <Avatar
              name="Adepto"
              role="Cobarde"
              cardCount={turn === 2 ? 3 : 1}
              isTurn={turn === 2}
              className="scale-90"
            />
            <Avatar name="Oraculo" role="Caotico" cardCount={5} isTurn={turn === 4} className="scale-90" />
          </div>

          <main className="relative flex h-[calc(100dvh-220px)] flex-col">
            <div className="relative flex flex-1 items-center justify-center rounded-2xl border border-[rgba(81,64,130,0.45)] bg-[rgba(10,8,18,0.45)]">
              <div className="absolute left-[20%] top-1/2 -translate-y-1/2">
                <div className="relative">
                  <PlayingCard suit="ash" rank="1" isFaceDown />
                  <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 rounded-full border border-[rgba(85,67,136,0.7)] bg-[rgba(24,18,43,0.9)] px-2 py-0.5 text-xs">
                    24
                  </div>
                </div>
              </div>

              <motion.div
                key={`${centerCard.suit}-${centerCard.rank}`}
                initial={{ scale: 0.8, opacity: 0, rotate: -9 }}
                animate={{ scale: 1, opacity: 1, rotate: 0 }}
                className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
              >
                <PlayingCard suit={centerCard.suit as any} rank={centerCard.rank as any} />
              </motion.div>

              <div className="absolute right-[8%] top-[20%] text-[var(--eclipse-text-faint)]">
                <SunMoon className="h-6 w-6" />
              </div>
            </div>

            <motion.div
              key={message}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="mx-auto mt-3 w-full max-w-xl rounded-xl border border-[rgba(87,70,141,0.58)] bg-[rgba(25,19,46,0.9)] px-4 py-2"
            >
              <p className="text-center text-xs font-semibold tracking-[0.08em] sm:text-sm">{message}</p>
            </motion.div>

            <AnimatePresence>
              {showEclipseButton && (
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0, opacity: 0 }}
                  className="absolute bottom-28 left-1/2 z-40 -translate-x-1/2"
                >
                  <Button
                    variant="danger"
                    size="xl"
                    className="h-24 w-24 rounded-2xl text-xl font-extrabold shadow-[0_0_30px_rgba(218,69,92,0.55)]"
                    onClick={handleEclipse}
                  >
                    Eclipse
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </main>

          <div className="flex items-start justify-center pt-10">
            <ShadowMeter value={turn >= 3 ? 2 : 1} orientation="vertical" />
          </div>
        </div>

        <div className="absolute inset-x-0 bottom-0 z-30 pb-[calc(1rem+env(safe-area-inset-bottom))]">
          <div className="mx-auto flex max-w-3xl items-end justify-center gap-3 px-3">
            <Avatar name="Tu" isTurn={turn === 0 || turn === 3 || turn === 5} />
            <div className="eclipse-scrollbar flex flex-1 items-end justify-start gap-2 overflow-x-auto pb-1 pr-1">
              <AnimatePresence>
                {userHand.map((card, i) => (
                  <motion.div
                    key={`${card.suit}-${card.rank}-${i}`}
                    initial={{ y: 100, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: 100, opacity: 0 }}
                  >
                    <PlayingCard
                      suit={card.suit as any}
                      rank={card.rank as any}
                      isPlayable={card.isPlayable}
                      className="min-w-[5.5rem]"
                      onClick={() => handlePlayCard(i)}
                    />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      <OverlayPanel open={showSettings} onClose={() => setShowSettings(false)} title="Ajustes de practica">
        <SettingsControls settings={settings} onChange={onSettingsChange} showTutorialSpeed />
        <div className="mt-3">
          <Button variant="secondary" size="md" className="w-full rounded-xl" onClick={() => setShowSettings(false)}>
            Cerrar
          </Button>
        </div>
      </OverlayPanel>
    </div>
  );
}
