import * as React from "react";
import { motion } from "motion/react";
import { cn } from "../utils/cn";
import { Flame, Droplet, Moon, Skull, Sparkles, Zap } from "lucide-react";

export type CardSuit = "blood" | "shadow" | "ash" | "bone" | "ritual" | "action";
export type CardRank =
  | "1"
  | "2"
  | "3"
  | "4"
  | "5"
  | "6"
  | "7"
  | "8"
  | "9"
  | "10"
  | "J"
  | "Q"
  | "K"
  | "A"
  | "RITUAL"
  | "ACCION"
  | "ACCIÓN";

export interface CardProps {
  suit: CardSuit;
  rank: CardRank;
  isPlayable?: boolean;
  isFaceDown?: boolean;
  className?: string;
  onClick?: () => void;
  style?: React.CSSProperties;
  cost?: number;
}

const suitConfig = {
  blood: {
    color: "text-rose-500",
    tint: "from-rose-500/30 to-rose-900/10",
    glow: "0 0 24px rgba(244, 63, 94, 0.48)",
    icon: Droplet,
  },
  shadow: {
    color: "text-violet-300",
    tint: "from-violet-400/32 to-violet-900/12",
    glow: "0 0 26px rgba(167, 139, 250, 0.55)",
    icon: Moon,
  },
  ash: {
    color: "text-slate-300",
    tint: "from-slate-300/25 to-slate-700/10",
    glow: "0 0 22px rgba(148, 163, 184, 0.45)",
    icon: Flame,
  },
  bone: {
    color: "text-amber-300",
    tint: "from-amber-300/30 to-amber-900/12",
    glow: "0 0 25px rgba(251, 191, 36, 0.5)",
    icon: Skull,
  },
  ritual: {
    color: "text-fuchsia-300",
    tint: "from-fuchsia-300/35 to-fuchsia-900/12",
    glow: "0 0 28px rgba(216, 180, 254, 0.56)",
    icon: Sparkles,
  },
  action: {
    color: "text-sky-300",
    tint: "from-sky-300/35 to-sky-900/12",
    glow: "0 0 24px rgba(125, 211, 252, 0.48)",
    icon: Zap,
  },
};

export function PlayingCard({
  suit,
  rank,
  isPlayable,
  isFaceDown,
  className,
  onClick,
  style,
  cost,
}: CardProps) {
  const config = suitConfig[suit] || suitConfig.ash;
  const Icon = config.icon;
  const rankText = String(rank);
  const isLongRank = rankText.length > 2;
  const cornerRank =
    rankText === "RITUAL"
      ? "RIT"
      : rankText === "ACCION" || rankText === "ACCIÓN"
        ? "ACT"
        : rankText;

  if (isFaceDown) {
    return (
      <motion.div
        className={cn(
          "relative flex h-32 w-[5.5rem] cursor-pointer items-center justify-center overflow-hidden rounded-xl border border-[rgba(117,87,188,0.55)] bg-[linear-gradient(165deg,#2b1f52,#150f2a)] shadow-2xl sm:h-48 sm:w-32",
          className,
        )}
        style={style}
        whileHover={{ y: -10, rotateZ: (Math.random() - 0.5) * 5 }}
      >
        <div className="absolute inset-1.5 rounded-lg border border-[rgba(167,139,250,0.36)] opacity-85" />
        <div className="absolute inset-3 rounded-md border border-[rgba(200,154,23,0.25)] opacity-50" />
        <div className="absolute inset-0 bg-noise opacity-25" />
        <div className="flex h-14 w-14 items-center justify-center rounded-full border border-[rgba(200,154,23,0.45)] bg-[rgba(15,11,29,0.85)] shadow-[0_0_22px_rgba(139,92,246,0.4)]">
          <Moon className="h-7 w-7 text-[rgba(200,154,23,0.9)]" />
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      onClick={onClick}
      className={cn(
        "relative flex h-32 w-[5.5rem] select-none flex-col justify-between overflow-hidden rounded-xl border bg-[linear-gradient(170deg,#23193f,#120e22)] p-2 text-white shadow-[0_16px_28px_rgba(0,0,0,0.42)] transition-colors duration-300 sm:h-48 sm:w-32 sm:p-3",
        isPlayable
          ? "cursor-pointer border-[rgba(157,118,255,0.92)]"
          : "cursor-not-allowed border-[rgba(85,67,136,0.65)] opacity-100 grayscale-[0.2] brightness-[0.88]",
        className,
      )}
      style={style}
      whileHover={isPlayable ? { y: -15, scale: 1.05, zIndex: 50 } : {}}
      animate={
        isPlayable
          ? {
              boxShadow: [
                "0 0 0 rgba(0,0,0,0)",
                config.glow,
                "0 0 0 rgba(0,0,0,0)",
              ],
            }
          : undefined
      }
      transition={{ duration: 2.2, repeat: Infinity }}
    >
      <div className="pointer-events-none absolute inset-0 bg-noise opacity-20" />
      <div
        className={cn(
          "pointer-events-none absolute inset-0 bg-gradient-to-b opacity-70",
          config.tint,
        )}
      />
      <div className="pointer-events-none absolute inset-1 rounded-lg border border-white/6" />
      {isPlayable && (
        <div className="pointer-events-none absolute inset-0 rounded-xl border border-[rgba(173,130,255,0.6)] shadow-[inset_0_0_16px_rgba(157,118,255,0.45)]" />
      )}

      <div
        className={cn(
          "relative z-10 flex flex-col items-center",
          isLongRank ? "w-8 sm:w-9" : "w-5 sm:w-6",
          config.color,
        )}
      >
        <span
          className={cn(
            "font-mono font-bold leading-none",
            isLongRank ? "text-[9px] tracking-[0.08em] sm:text-xs" : "text-base sm:text-2xl",
          )}
        >
          {cornerRank}
        </span>
        <Icon className="mt-0.5 h-3.5 w-3.5 opacity-90 sm:mt-1 sm:h-5 sm:w-5" />
      </div>

      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
        <Icon
          className={cn(
            "h-16 w-16 drop-shadow-2xl sm:h-24 sm:w-24",
            config.color,
          )}
        />
      </div>
      {isLongRank && (
        <div className="pointer-events-none absolute left-1/2 top-1/2 z-10 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/10 bg-black/30 px-2 py-1">
          <p className="eclipse-subtitle text-[7px] tracking-[0.16em] text-white/80 sm:text-[8px]">
            {rankText}
          </p>
        </div>
      )}

      {cost !== undefined && (
        <div className="absolute right-1.5 top-1.5 z-20 flex h-5 w-5 items-center justify-center rounded-full border border-[rgba(200,154,23,0.75)] bg-[rgba(27,20,48,0.95)] text-[10px] font-bold text-[rgba(247,246,253,1)] shadow-[0_0_14px_rgba(200,154,23,0.4)] sm:right-2 sm:top-2 sm:h-7 sm:w-7 sm:text-sm">
          {cost}
        </div>
      )}

      <div
        className={cn(
          "relative z-10 flex rotate-180 flex-col items-center self-end",
          isLongRank ? "w-8 sm:w-9" : "w-5 sm:w-6",
          config.color,
        )}
      >
        <span
          className={cn(
            "font-mono font-bold leading-none",
            isLongRank ? "text-[9px] tracking-[0.08em] sm:text-xs" : "text-base sm:text-2xl",
          )}
        >
          {cornerRank}
        </span>
        <Icon className="mt-0.5 h-3.5 w-3.5 opacity-90 sm:mt-1 sm:h-5 sm:w-5" />
      </div>
    </motion.div>
  );
}
