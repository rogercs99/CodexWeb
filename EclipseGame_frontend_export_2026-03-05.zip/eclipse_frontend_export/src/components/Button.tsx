import * as React from "react";
import { motion } from "motion/react";
import { cn } from "../utils/cn";
import { emitSfx } from "../audio/events";
import { audioManager } from "../audio/audioManager";
import { triggerHaptic } from "../lib/haptics";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "danger" | "ritual";
  size?: "sm" | "md" | "lg" | "xl";
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    { className, variant = "primary", size = "md", children, onClick, ...props },
    ref,
  ) => {
    const baseStyles =
      "relative inline-flex min-w-0 items-center justify-center text-center font-semibold leading-tight transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[rgba(200,154,23,0.45)] disabled:pointer-events-none disabled:opacity-50 overflow-hidden uppercase whitespace-normal";

    const variants = {
      primary:
        "eclipse-cta text-[var(--eclipse-text)] tracking-[0.1em] hover:shadow-[0_0_18px_rgba(139,92,246,0.52)]",
      secondary:
        "bg-[linear-gradient(160deg,rgba(26,21,47,0.95),rgba(14,11,26,0.95))] text-[var(--eclipse-text)] tracking-[0.08em] border border-[rgba(82,66,132,0.6)] hover:border-[rgba(132,104,217,0.8)]",
      ghost:
        "bg-transparent text-[var(--eclipse-text-muted)] tracking-[0.08em] hover:text-[var(--eclipse-text)] hover:bg-[rgba(118,88,190,0.14)]",
      danger:
        "bg-[linear-gradient(180deg,rgba(160,28,42,0.95),rgba(120,12,26,0.98))] text-[#ffe8ef] border border-[rgba(218,69,92,0.72)] tracking-[0.06em] hover:bg-[linear-gradient(180deg,rgba(180,35,50,0.95),rgba(140,18,32,0.98))] hover:shadow-[0_0_18px_rgba(218,69,92,0.55)]",
      ritual:
        "bg-[linear-gradient(150deg,rgba(88,49,174,0.95),rgba(56,31,114,0.97))] text-[var(--eclipse-text)] border border-[rgba(157,118,255,0.9)] tracking-[0.08em] hover:bg-[linear-gradient(150deg,rgba(100,56,190,0.95),rgba(63,35,126,0.97))] hover:shadow-[0_0_20px_rgba(157,118,255,0.45)]",
    };

    const sizes = {
      sm: "min-h-8 px-3 py-1 text-[10px] sm:text-[11px]",
      md: "min-h-10 px-4 py-1.5 text-xs sm:text-sm",
      lg: "min-h-12 px-5 py-2 text-sm sm:text-base",
      xl: "min-h-14 px-6 py-2 text-base sm:text-lg",
    };

    const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
      if (!props.disabled) {
        void audioManager.unlock();
        emitSfx("ui_click");
        triggerHaptic(variant === "danger" ? "heavy" : variant === "ghost" ? "soft" : "tap");
      }
      onClick?.(event);
    };

    return (
      <motion.button
        ref={ref}
        data-feedback="managed"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        className={cn(baseStyles, variants[variant], sizes[size], className)}
        onClick={handleClick}
        {...props}
      >
        <span className="relative z-10 flex items-center gap-2">
          {children}
        </span>
        {(variant === "primary" || variant === "ritual") && (
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/35 via-transparent to-white/8" />
        )}
      </motion.button>
    );
  },
);
Button.displayName = "Button";
