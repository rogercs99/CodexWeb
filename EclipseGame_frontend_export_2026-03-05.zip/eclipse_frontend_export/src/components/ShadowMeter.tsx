import { motion } from "motion/react";
import { cn } from "../utils/cn";

export interface ShadowMeterProps {
  value: number;
  max?: number;
  className?: string;
  orientation?: "horizontal" | "vertical";
}

export function ShadowMeter({
  value,
  max = 6,
  className,
  orientation = "horizontal",
}: ShadowMeterProps) {
  const isVertical = orientation === "vertical";

  return (
    <div className={cn("flex flex-col items-center gap-2", className)}>
      <span className="eclipse-subtitle text-[10px] text-[rgba(200,154,23,0.9)]">
        Sombra
      </span>
      <div
        className={cn(
          "rounded-full border border-[rgba(84,66,137,0.8)] bg-[rgba(20,16,37,0.95)] p-2 shadow-[0_10px_22px_rgba(0,0,0,0.35)] backdrop-blur-md",
          isVertical ? "flex flex-col-reverse gap-1" : "flex gap-1.5",
        )}
      >
        {Array.from({ length: max }).map((_, i) => {
          const isActive = i < value;
          return (
            <div
              key={i}
              className={cn(
                "relative overflow-hidden rounded-sm border border-[rgba(103,80,165,0.52)] bg-[rgba(8,6,15,0.9)]",
                isVertical ? "h-7 w-4 sm:h-9 sm:w-5" : "h-8 w-4 sm:h-10 sm:w-5",
              )}
              style={{
                clipPath:
                  "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)",
              }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-t from-[#5f3eac] via-[#8b5cf6] to-[#d6bcff]"
                initial={{ y: "100%" }}
                animate={{ y: isActive ? "0%" : "100%" }}
                transition={{ type: "spring", stiffness: 120, damping: 16 }}
              />
              {isActive && (
                <motion.div
                  className="absolute inset-0 bg-white/[0.18]"
                  animate={{ opacity: [0, 0.5, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
