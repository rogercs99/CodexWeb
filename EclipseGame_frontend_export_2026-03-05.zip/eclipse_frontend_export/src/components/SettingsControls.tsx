import type { ReactElement } from "react";
import { Bell, Sparkles, Swords, Vibrate, Volume2, Wand2 } from "lucide-react";
import type { GameSettings } from "../types/game";

interface Props {
  settings: GameSettings;
  onChange: (patch: Partial<GameSettings>) => void;
  showTutorialSpeed?: boolean;
}

function LabeledSlider({
  label,
  value,
  onChange,
  icon,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  icon: ReactElement;
}) {
  return (
    <label className="group block rounded-2xl border border-[rgba(224,232,247,0.22)] bg-[linear-gradient(170deg,rgba(16,17,23,0.95),rgba(7,7,10,0.98))] p-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)] transition-colors hover:border-[rgba(224,232,247,0.38)]">
      <div className="mb-2 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <span className="text-[var(--eclipse-gold)]">{icon}</span>
          <span className="eclipse-subtitle tracking-[0.14em] text-[var(--eclipse-accent-soft)]">{label}</span>
        </div>
        <span className="rounded-full border border-[rgba(210,181,111,0.4)] bg-[rgba(32,25,14,0.68)] px-2 py-0.5 font-semibold text-[var(--eclipse-gold)]">
          {value}%
        </span>
      </div>
      <input
        type="range"
        min={0}
        max={100}
        value={value}
        onChange={(event) => onChange(Number(event.currentTarget.value))}
        className="w-full accent-[var(--eclipse-gold)]"
      />
    </label>
  );
}

function ToggleRow({
  label,
  value,
  onChange,
  icon,
}: {
  label: string;
  value: boolean;
  onChange: (value: boolean) => void;
  icon: ReactElement;
}) {
  return (
    <label className="flex cursor-pointer items-center justify-between rounded-2xl border border-[rgba(208,214,232,0.26)] bg-[linear-gradient(180deg,rgba(15,16,22,0.96),rgba(8,8,11,0.98))] px-3 py-2.5 text-sm">
      <span className="flex items-center gap-2">
        <span className="text-[var(--eclipse-gold)]">{icon}</span>
        <span>{label}</span>
      </span>
      <span className="relative">
        <input
          type="checkbox"
          checked={value}
          onChange={(event) => onChange(event.currentTarget.checked)}
          className="peer sr-only"
        />
        <span className="block h-6 w-11 rounded-full border border-[rgba(222,229,247,0.24)] bg-[rgba(40,40,48,0.9)] transition-colors peer-checked:border-[rgba(210,181,111,0.5)] peer-checked:bg-[rgba(70,55,28,0.92)]" />
        <span className="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-[rgba(231,237,251,0.9)] transition-transform peer-checked:translate-x-5 peer-checked:bg-[var(--eclipse-gold)]" />
      </span>
    </label>
  );
}

export function SettingsControls({ settings, onChange, showTutorialSpeed = false }: Props) {
  return (
    <div className="space-y-3 text-sm">
      <div className="rounded-2xl border border-[rgba(224,232,247,0.2)] bg-[rgba(10,10,14,0.55)] p-3">
        <p className="eclipse-subtitle text-[10px] text-[var(--eclipse-accent-soft)]">Audio</p>
      </div>
      <LabeledSlider
        label="Volumen maestro"
        value={settings.masterVolume}
        onChange={(value) => onChange({ masterVolume: value })}
        icon={<Volume2 className="h-4 w-4" />}
      />
      <LabeledSlider
        label="Musica"
        value={settings.musicVolume}
        onChange={(value) => onChange({ musicVolume: value })}
        icon={<Bell className="h-4 w-4" />}
      />
      <LabeledSlider
        label="Efectos"
        value={settings.sfxVolume}
        onChange={(value) => onChange({ sfxVolume: value })}
        icon={<Sparkles className="h-4 w-4" />}
      />

      <div className="rounded-2xl border border-[rgba(224,232,247,0.2)] bg-[rgba(10,10,14,0.55)] p-3">
        <p className="eclipse-subtitle text-[10px] text-[var(--eclipse-accent-soft)]">Gameplay</p>
      </div>
      <ToggleRow
        label="Respuesta haptica"
        value={settings.haptics}
        onChange={(value) => onChange({ haptics: value })}
        icon={<Vibrate className="h-4 w-4" />}
      />
      <ToggleRow
        label="Animaciones"
        value={settings.animations}
        onChange={(value) => onChange({ animations: value })}
        icon={<Wand2 className="h-4 w-4" />}
      />
      <ToggleRow
        label="Ayudas visuales"
        value={settings.visualHints}
        onChange={(value) => onChange({ visualHints: value })}
        icon={<Sparkles className="h-4 w-4" />}
      />
      <ToggleRow
        label="Mensajes guiados"
        value={settings.guidedMessages}
        onChange={(value) => onChange({ guidedMessages: value })}
        icon={<Swords className="h-4 w-4" />}
      />

      {showTutorialSpeed && (
        <label className="block rounded-2xl border border-[rgba(208,214,232,0.28)] bg-[linear-gradient(180deg,rgba(14,15,21,0.95),rgba(8,8,12,0.96))] p-3">
          <span className="eclipse-subtitle text-[10px] tracking-[0.14em] text-[var(--eclipse-accent-soft)]">
            Velocidad tutorial
          </span>
          <select
            value={settings.tutorialSpeed}
            onChange={(event) => onChange({ tutorialSpeed: event.currentTarget.value as GameSettings["tutorialSpeed"] })}
            className="mt-2 w-full rounded-lg border border-[rgba(211,218,238,0.36)] bg-[rgba(7,8,12,0.95)] px-2 py-2 text-sm"
          >
            <option value="slow">Lenta</option>
            <option value="normal">Normal</option>
            <option value="fast">Rapida</option>
          </select>
        </label>
      )}
    </div>
  );
}
