import { motion } from "motion/react";
import { cn } from "../utils/cn";

export function FogBackground({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "fixed inset-0 pointer-events-none overflow-hidden z-0 bg-noise",
        className,
      )}
    >
      <div className="absolute inset-0 eclipse-shell" />
      <div className="absolute inset-0 eclipse-vignette z-10" />

      <div className="absolute inset-0 opacity-10 eclipse-grid-lines" />

      <div className="absolute inset-0 flex items-center justify-center opacity-35">
        <div className="w-[74vw] max-w-[460px] aspect-square rounded-full eclipse-orb" />
      </div>

      <motion.div
        className="absolute inset-0 opacity-35 mix-blend-screen"
        style={{
          backgroundImage:
            "radial-gradient(circle at 50% 45%, rgba(221, 228, 247, 0.24) 0%, transparent 62%)",
          backgroundSize: "200% 200%",
        }}
        animate={{
          backgroundPosition: ["0% 0%", "100% 100%", "0% 0%"],
        }}
        transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
      />
      <motion.div
        className="absolute inset-0 opacity-30 mix-blend-screen"
        style={{
          backgroundImage:
            "radial-gradient(circle at 30% 68%, rgba(200, 154, 23, 0.16) 0%, transparent 50%)",
          backgroundSize: "150% 150%",
        }}
        animate={{
          backgroundPosition: ["100% 0%", "0% 100%", "100% 0%"],
        }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
      />

      <div className="absolute inset-0">
        {[...Array(14)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-[rgba(200,154,23,0.72)] shadow-[0_0_8px_rgba(200,154,23,0.9)]"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -120 - Math.random() * 80],
              x: [0, (Math.random() - 0.5) * 50],
              opacity: [0, 0.75, 0],
              scale: [0, Math.random() * 2 + 0.5, 0],
            }}
            transition={{
              duration: Math.random() * 7 + 6,
              repeat: Infinity,
              delay: Math.random() * 4,
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      <div className="absolute inset-x-0 bottom-0 h-56 bg-gradient-to-t from-[rgba(5,3,10,0.88)] to-transparent" />
    </div>
  );
}
