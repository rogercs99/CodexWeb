import type { ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import { X } from "lucide-react";
import { Button } from "./Button";
import { cn } from "../utils/cn";

interface OverlayPanelProps {
  open: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
  className?: string;
}

export function OverlayPanel({
  open,
  title,
  onClose,
  children,
  className,
}: OverlayPanelProps) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.button
            type="button"
            aria-label="Cerrar panel"
            className="fixed inset-0 z-40 bg-[rgba(4,3,10,0.7)] backdrop-blur-[2px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          <motion.section
            initial={{ y: 36, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 36, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className={cn(
              "fixed inset-x-3 bottom-3 z-50 max-h-[72vh] overflow-y-auto rounded-2xl border border-[rgba(118,88,190,0.55)] bg-[linear-gradient(180deg,rgba(27,20,50,0.98),rgba(10,8,19,0.99))] p-4 shadow-[0_24px_56px_rgba(0,0,0,0.62)] sm:inset-x-auto sm:right-6 sm:top-6 sm:bottom-auto sm:w-[26rem]",
              className,
            )}
          >
            <header className="mb-3 flex items-center justify-between gap-3">
              <h3 className="eclipse-title text-sm text-[var(--eclipse-gold)]">{title}</h3>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="rounded-lg px-2"
                onClick={onClose}
              >
                <X className="h-4 w-4" />
              </Button>
            </header>
            {children}
          </motion.section>
        </>
      )}
    </AnimatePresence>
  );
}
