import { cn } from "../utils/cn";
import { motion } from "motion/react";

export interface AvatarProps {
  name: string;
  role?: string;
  cardCount?: number | string;
  isTurn?: boolean;
  className?: string;
  avatarUrl?: string;
}

export function Avatar({
  name,
  role,
  cardCount,
  isTurn,
  className,
  avatarUrl,
}: AvatarProps) {
  return (
    <div className={cn("relative flex min-w-16 flex-col items-center gap-2", className)}>
      <motion.div
        className={cn(
          "relative h-14 w-14 overflow-hidden rounded-full border-2 bg-[linear-gradient(160deg,#2f2253,#181029)] sm:h-20 sm:w-20",
          isTurn
            ? "border-[rgba(200,154,23,0.85)] shadow-[0_0_20px_rgba(139,92,246,0.7)]"
            : "border-[rgba(103,80,165,0.5)]",
        )}
        animate={isTurn ? { scale: [1, 1.05, 1] } : {}}
        transition={{ duration: 2, repeat: Infinity }}
      >
        {avatarUrl ? (
          <img
            src={avatarUrl}
            alt={name}
            className="w-full h-full object-cover opacity-80"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-xl font-bold text-[rgba(200,154,23,0.9)]">
            {name.charAt(0)}
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
      </motion.div>

      <div className="max-w-[6rem] text-center sm:max-w-[9rem]">
        <h3 className="eclipse-title break-words text-[10px] leading-tight text-[var(--eclipse-text)] sm:text-xs">
          {name}
        </h3>
        {role && (
          <p className="eclipse-faint break-words text-[9px] uppercase leading-tight tracking-[0.12em] sm:text-[10px]">
            {role}
          </p>
        )}
      </div>

      {cardCount !== undefined && (
        <div className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full border border-[rgba(200,154,23,0.72)] bg-[rgba(26,20,48,0.95)] text-[10px] font-bold text-[rgba(247,246,253,1)] shadow-[0_0_10px_rgba(139,92,246,0.6)] sm:h-8 sm:w-8 sm:text-xs">
          {cardCount}
        </div>
      )}
    </div>
  );
}
