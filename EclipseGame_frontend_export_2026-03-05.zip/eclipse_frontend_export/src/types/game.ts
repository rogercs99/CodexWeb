export type TutorialSpeed = "slow" | "normal" | "fast";

export interface GameSettings {
  masterVolume: number;
  musicVolume: number;
  sfxVolume: number;
  haptics: boolean;
  animations: boolean;
  visualHints: boolean;
  guidedMessages: boolean;
  tutorialSpeed: TutorialSpeed;
}

export const defaultGameSettings: GameSettings = {
  masterVolume: 82,
  musicVolume: 70,
  sfxVolume: 78,
  haptics: true,
  animations: true,
  visualHints: true,
  guidedMessages: true,
  tutorialSpeed: "normal",
};

export const SETTINGS_STORAGE_KEY = "eclipse.settings.v1";
