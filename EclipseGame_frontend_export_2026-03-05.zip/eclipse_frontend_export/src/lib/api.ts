export interface AuthUser {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  xp: number;
  level: number;
  wins: number;
  matches: number;
  createdAt: string;
}

export interface SocialUser extends AuthUser {
  isFriend: boolean;
}

export interface ClubStats {
  players: number;
  friendships: number;
  avgLevel: number;
}

const TOKEN_STORAGE_KEY = "eclipse.auth.token";
const API_BASE = String(import.meta.env.VITE_API_BASE || "").trim();

export function getAuthToken(): string | null {
  return localStorage.getItem(TOKEN_STORAGE_KEY);
}

export function setAuthToken(token: string | null): void {
  if (!token) {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    return;
  }
  localStorage.setItem(TOKEN_STORAGE_KEY, token);
}

interface ApiOptions extends RequestInit {
  auth?: boolean;
}

async function api<T>(url: string, init?: ApiOptions): Promise<T> {
  const headers = new Headers(init?.headers);
  if (!headers.has("Content-Type") && init?.body) {
    headers.set("Content-Type", "application/json");
  }

  if (init?.auth !== false) {
    const token = getAuthToken();
    if (token) {
      headers.set("Authorization", `Bearer ${token}`);
    }
  }

  const res = await fetch(`${API_BASE}${url}`, {
    ...init,
    headers,
  });

  const json = (await res.json().catch(() => ({}))) as {
    ok?: boolean;
    error?: string;
  };

  if (!res.ok || json.ok === false) {
    throw new Error(json.error || `Request failed (${res.status})`);
  }

  return json as T;
}

export async function register(payload: {
  username: string;
  password: string;
  displayName?: string;
}): Promise<{ token: string; user: AuthUser }> {
  const data = await api<{ ok: true; token: string; user: AuthUser }>("/api/auth/register", {
    method: "POST",
    body: JSON.stringify(payload),
    auth: false,
  });
  return { token: data.token, user: data.user };
}

export async function login(payload: { username: string; password: string }): Promise<{ token: string; user: AuthUser }> {
  const data = await api<{ ok: true; token: string; user: AuthUser }>("/api/auth/login", {
    method: "POST",
    body: JSON.stringify(payload),
    auth: false,
  });
  return { token: data.token, user: data.user };
}

export async function logout(): Promise<void> {
  await api<{ ok: true }>("/api/auth/logout", {
    method: "POST",
  });
}

export async function getMe(): Promise<{ user: AuthUser; stats: { friends: number } }> {
  const data = await api<{ ok: true; user: AuthUser; stats: { friends: number } }>("/api/auth/me");
  return { user: data.user, stats: data.stats };
}

export async function getClubStats(): Promise<ClubStats> {
  const data = await api<{ ok: true; stats: ClubStats }>("/api/club/stats", {
    auth: false,
  });
  return data.stats;
}

export async function getLeaderboard(limit = 10): Promise<AuthUser[]> {
  const data = await api<{ ok: true; users: AuthUser[] }>(`/api/club/leaderboard?limit=${encodeURIComponent(String(limit))}`, {
    auth: false,
  });
  return data.users;
}

export async function searchUsers(query: string, limit = 20): Promise<SocialUser[]> {
  const q = encodeURIComponent(query);
  const data = await api<{ ok: true; users: SocialUser[] }>(`/api/social/users?q=${q}&limit=${limit}`);
  return data.users;
}

export async function listFriends(): Promise<SocialUser[]> {
  const data = await api<{ ok: true; friends: SocialUser[] }>("/api/social/friends");
  return data.friends;
}

export async function addFriend(payload: {
  targetUserId?: string;
  targetUsername?: string;
}): Promise<SocialUser[]> {
  const data = await api<{ ok: true; friends: SocialUser[] }>("/api/social/friends", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  return data.friends;
}

export async function reportMatchResult(didWin: boolean): Promise<AuthUser> {
  const data = await api<{ ok: true; user: AuthUser }>("/api/progression/match", {
    method: "POST",
    body: JSON.stringify({ didWin }),
  });
  return data.user;
}

export async function updateProfile(payload: {
  displayName?: string;
  avatarUrl?: string | null;
}): Promise<AuthUser> {
  const data = await api<{ ok: true; user: AuthUser }>("/api/profile", {
    method: "PATCH",
    body: JSON.stringify(payload),
  });
  return data.user;
}
