type HapticPattern = "tap" | "soft" | "heavy" | "success" | "error";

let enabled = true;

const PATTERNS: Record<HapticPattern, number | number[]> = {
  tap: 12,
  soft: 7,
  heavy: 24,
  success: [10, 24, 10],
  error: [26, 34, 26],
};

function canVibrate(): boolean {
  return typeof navigator !== "undefined" && typeof navigator.vibrate === "function";
}

export function configureHaptics(nextEnabled: boolean): void {
  enabled = nextEnabled;
}

export function triggerHaptic(pattern: HapticPattern = "tap"): void {
  if (!enabled || !canVibrate()) {
    return;
  }
  navigator.vibrate(PATTERNS[pattern]);
}

