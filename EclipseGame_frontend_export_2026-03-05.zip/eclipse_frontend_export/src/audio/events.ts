export type SfxType =
  | "ui_click"
  | "card_play"
  | "draw"
  | "eclipse_call"
  | "panel_open"
  | "panel_close"
  | "reaction"
  | "ritual";

export type AudioScene = "auth" | "menu" | "tutorial" | "match";

export function emitSfx(type: SfxType): void {
  window.dispatchEvent(new CustomEvent("eclipse:sfx", { detail: { type } }));
}

export function emitScene(scene: AudioScene): void {
  window.dispatchEvent(new CustomEvent("eclipse:scene", { detail: { scene } }));
}

export function emitAudioUnlock(): void {
  window.dispatchEvent(new CustomEvent("eclipse:audioUnlock"));
}
