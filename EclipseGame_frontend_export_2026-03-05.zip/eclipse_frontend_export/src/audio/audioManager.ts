import type { AudioScene, SfxType } from "./events";

type Wave = OscillatorType;

interface ToneSpec {
  freq: number;
  duration: number;
  gain: number;
  type?: Wave;
  delay?: number;
}

const SCENE_TEMPO_MS: Record<AudioScene, number> = {
  auth: 2800,
  menu: 2400,
  tutorial: 1800,
  match: 1400,
};

export class AudioManager {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private currentScene: AudioScene = "menu";
  private timerId: number | null = null;
  private unlocked = false;
  private masterVolume = 0.82;
  private musicVolume = 0.7;
  private sfxVolume = 0.78;

  private initContext(): {
    ctx: AudioContext;
    master: GainNode;
    music: GainNode;
    sfx: GainNode;
  } {
    if (this.ctx && this.masterGain && this.musicGain && this.sfxGain) {
      return { ctx: this.ctx, master: this.masterGain, music: this.musicGain, sfx: this.sfxGain };
    }

    const ctx = new AudioContext();
    const master = ctx.createGain();
    const music = ctx.createGain();
    const sfx = ctx.createGain();
    music.connect(master);
    sfx.connect(master);
    master.connect(ctx.destination);

    this.masterGain = master;
    this.musicGain = music;
    this.sfxGain = sfx;
    this.ctx = ctx;
    this.applyVolumes();
    return { ctx, master, music, sfx };
  }

  private applyVolumes(): void {
    if (!this.ctx || !this.masterGain || !this.musicGain || !this.sfxGain) {
      return;
    }
    this.masterGain.gain.value = this.masterVolume;
    this.musicGain.gain.value = this.musicVolume;
    this.sfxGain.gain.value = this.sfxVolume;
  }

  setVolumes(input: { master: number; music: number; sfx: number }): void {
    this.masterVolume = Math.min(Math.max(input.master / 100, 0), 1);
    this.musicVolume = Math.min(Math.max(input.music / 100, 0), 1);
    this.sfxVolume = Math.min(Math.max(input.sfx / 100, 0), 1);
    this.applyVolumes();
  }

  async unlock(): Promise<void> {
    const { ctx } = this.initContext();
    if (ctx.state === "suspended") {
      await ctx.resume();
    }
    this.unlocked = true;
    this.ensureSceneLoop();
  }

  setScene(scene: AudioScene): void {
    this.currentScene = scene;
    this.ensureSceneLoop();
  }

  playEffect(type: SfxType): void {
    if (!this.unlocked) {
      return;
    }
    const { ctx, sfx } = this.initContext();
    const now = ctx.currentTime;

    const queue = (tones: ToneSpec[]) => {
      for (const tone of tones) {
        this.playTone({
          ctx,
          target: sfx,
          freq: tone.freq,
          duration: tone.duration,
          gain: tone.gain,
          type: tone.type ?? "triangle",
          at: now + (tone.delay ?? 0),
        });
      }
    };

    if (type === "ui_click") {
      queue([
        { freq: 460, duration: 0.06, gain: 0.06, type: "triangle" },
        { freq: 620, duration: 0.04, gain: 0.04, delay: 0.04, type: "sine" },
      ]);
      return;
    }

    if (type === "card_play") {
      queue([
        { freq: 220, duration: 0.09, gain: 0.08, type: "square" },
        { freq: 330, duration: 0.08, gain: 0.05, delay: 0.05, type: "triangle" },
      ]);
      return;
    }

    if (type === "draw") {
      queue([
        { freq: 370, duration: 0.05, gain: 0.06, type: "triangle" },
        { freq: 470, duration: 0.05, gain: 0.05, delay: 0.03, type: "sine" },
      ]);
      return;
    }

    if (type === "reaction") {
      queue([
        { freq: 740, duration: 0.07, gain: 0.07, type: "sawtooth" },
        { freq: 520, duration: 0.1, gain: 0.06, delay: 0.05, type: "triangle" },
      ]);
      return;
    }

    if (type === "ritual") {
      queue([
        { freq: 180, duration: 0.2, gain: 0.08, type: "sine" },
        { freq: 240, duration: 0.24, gain: 0.06, delay: 0.06, type: "triangle" },
        { freq: 320, duration: 0.18, gain: 0.05, delay: 0.14, type: "triangle" },
      ]);
      return;
    }

    if (type === "eclipse_call") {
      queue([
        { freq: 200, duration: 0.24, gain: 0.08, type: "square" },
        { freq: 300, duration: 0.24, gain: 0.07, delay: 0.09, type: "square" },
        { freq: 420, duration: 0.28, gain: 0.06, delay: 0.18, type: "triangle" },
      ]);
      return;
    }

    if (type === "panel_open") {
      queue([{ freq: 520, duration: 0.08, gain: 0.05, type: "sine" }]);
      return;
    }

    if (type === "panel_close") {
      queue([{ freq: 420, duration: 0.08, gain: 0.05, type: "sine" }]);
    }
  }

  private ensureSceneLoop(): void {
    if (!this.unlocked) {
      return;
    }
    if (this.timerId !== null) {
      window.clearInterval(this.timerId);
      this.timerId = null;
    }
    this.playScenePulse();
    this.timerId = window.setInterval(() => {
      this.playScenePulse();
    }, SCENE_TEMPO_MS[this.currentScene]);
  }

  private playScenePulse(): void {
    if (!this.unlocked) {
      return;
    }
    const { ctx, music } = this.initContext();
    const baseNow = ctx.currentTime;

    const chordByScene: Record<AudioScene, number[]> = {
      auth: [196, 247, 294],
      menu: [174, 220, 262],
      tutorial: [208, 262, 311],
      match: [155, 196, 233],
    };

    const chord = chordByScene[this.currentScene];
    chord.forEach((freq, index) => {
      this.playTone({
        ctx,
        target: music,
        freq,
        duration: this.currentScene === "match" ? 0.85 : 1.2,
        gain: this.currentScene === "match" ? 0.03 : 0.025,
        at: baseNow + index * 0.05,
        type: index === 0 ? "sine" : "triangle",
      });
    });
  }

  private playTone(input: {
    ctx: AudioContext;
    target: GainNode;
    freq: number;
    duration: number;
    gain: number;
    at: number;
    type: Wave;
  }): void {
    const osc = input.ctx.createOscillator();
    const gain = input.ctx.createGain();
    osc.type = input.type;
    osc.frequency.value = input.freq;
    gain.gain.setValueAtTime(0.0001, input.at);
    gain.gain.exponentialRampToValueAtTime(input.gain, input.at + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, input.at + input.duration);
    osc.connect(gain);
    gain.connect(input.target);
    osc.start(input.at);
    osc.stop(input.at + input.duration + 0.02);
  }
}

export const audioManager = new AudioManager();
