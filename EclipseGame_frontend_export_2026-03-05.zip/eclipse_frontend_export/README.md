# ECLIPSE CLUB

Frontend + backend for a real-time multiplayer card game with deterministic server-authoritative rules and a first-time interactive tutorial.

## Stack

- Frontend: React + TypeScript + Vite + Tailwind
- Backend: Node.js + TypeScript + Express + Socket.IO
- Determinism: seeded RNG in game engine (`server/src/game/rng.ts`)

## Implemented Features

- Multiplayer rooms: create/join/leave by code
- Lobby readiness and start validation (`>= 3` players including bots)
- Server-authoritative hand secrecy:
  - owner sees full hand
  - others see card counts (or `few/medium/many` under Blackout)
- Core rules:
  - Suits `Ash/Blood/Bone/Mist` ranks `0-9`
  - Actions `Slash`, `MistSkip`, `GraveTurn`, `Echo`
  - Shadow resource `0..6`
  - Rituals `ColdHands`, `ShadowSteal`, `Duel`, `Blackout`
  - Reactions `BlackMirror`, `Redirect`
  - Eclipse call + penalty draw `2`
  - Win condition and `Ascension` when last card is ritual
- Bots for multiplayer:
  - difficulties: `Minion/Adept/Oracle`
  - personalities: `Cruel/Coward/Chaotic`
- Tutorial mode (scripted, deterministic, 6-turn flow)
  - fixed decks/hands
  - tutorial steps + hints + allowed action enforcement
  - tutorial reaction window at `3s`
  - skip/restart APIs
  - in-memory `hasCompletedTutorial` flag per user

## Project Structure

- `src/` frontend app and UI screens
- `server/src/index.ts` backend entrypoint
- `server/src/api/createServer.ts` Express app + Socket.IO wiring
- `server/src/game/room.ts` deterministic game room engine (multiplayer + tutorial script)
- `server/src/game/roomManager.ts` room lifecycle and player routing
- `server/src/game/bot.ts` multiplayer bot logic
- `server/src/game/tutorialScript.ts` fixed tutorial scenario and steps
- `server/src/store/tutorialProgressStore.ts` in-memory tutorial completion store
- `server/tests/*.test.ts` unit/integration test suite

## Run

```bash
npm install
npm run dev          # frontend on :3000
npm run dev:server   # backend on :8080
```

Backend health:

```bash
curl http://localhost:8080/health
```

## REST API

### `POST /tutorial/start`
Start or continue tutorial room for one user.

Body:

```json
{
  "userId": "user-123",
  "userName": "Roger"
}
```

### `POST /tutorial/restart`
Reset tutorial state and replay from step 1.

### `GET /tutorial/progress?userId=...`
Returns:

```json
{
  "ok": true,
  "progress": {
    "hasCompletedTutorial": true
  }
}
```

## WebSocket Event Contract

All socket events use Socket.IO.

### Client -> Server

- `session:attach` `{ playerId }`
- `room:create` `{ playerId, playerName, roomType?: "multiplayer" | "tutorial" }`
- `room:join` `{ code, playerId, playerName }`
- `room:leave` `{ playerId }`
- `room:ready` `{ playerId, ready }`
- `room:addBot` `{ playerId, difficulty, personality, name? }`
- `room:start` `{ playerId }`
- `room:snapshot` `{ playerId }`
- `action:playCard` `{ playerId, cardId, targetId?, blackoutSuit? }`
- `action:drawCard` `{ playerId, endTurn? }`
- `action:reaction` `{ playerId, cardId, redirectTargetId? }`
- `action:eclipseCall` `{ playerId }`
- `tutorial:skip` `{ playerId }`

### Server -> Client

- `room:state` -> player-private authoritative snapshot
- `game:event` -> engine events (`card_played`, `turn_started`, `reaction_window_opened`, `winner_declared`, etc.)
- `error:event` -> `{ message }`

### Tutorial Overlay Events

- `tutorial:stepChanged`

```json
{
  "stepId": "ritual_shadowsteal",
  "message": "Lanza ShadowSteal (cuesta 2 Shadow).",
  "allowedActions": ["playCard:t_u_steal"]
}
```

- `tutorial:hint`

```json
{
  "targetUIElementId": "tutorial-hand-card-shadowsteal"
}
```

- `tutorial:completed`

```json
{
  "roomId": "room_xxx",
  "userId": "user-123"
}
```

## Tests

Run backend tests:

```bash
npm run test:server
```

Includes:

- tutorial script reachability + transitions
- eclipse penalty and reaction handling
- integration flow (`/tutorial/start` + Socket actions -> `tutorial:completed`)

## Frontend Styling Adaptation

The frontend visuals were re-themed to match the attached design language:

- `Manrope` + gothic accent typography
- violet/gold palette and velvet gradients
- panel/glow system and occult ambiance in screens/components
- updated key screens: welcome, main menu, lobby, match

## Deployment Notes for `eclipse.gamemodai.pro`

This codebase is ready to deploy behind a reverse proxy.

Typical setup:

1. Build and run frontend static hosting (Vite build).
2. Run backend service (`npm run start:server`) on internal port (e.g. `8080`).
3. Configure Nginx/Caddy for:
   - HTTPS termination on `eclipse.gamemodai.pro`
   - proxy WebSocket upgrades to backend Socket.IO endpoint
   - serve frontend static assets

Example backend environment:

```bash
PORT=8080
NODE_ENV=production
```
